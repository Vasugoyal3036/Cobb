const express = require('express');
const cors = require('cors');
const { sql, connectDB } = require('./db');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { spawn, execSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const { checkPort } = require('./scanner');
require('dotenv').config();

const app = express();
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Bypass-Tunnel-Reminder', 'ngrok-skip-browser-warning', '*']
}));
app.use(express.json());

const { router: authRouter, checkRole } = require('./routes/auth');
app.use('/api/auth', authRouter);

const tunnelRouter = require('./routes/tunnel');
app.use('/api/tunnel', tunnelRouter);

const configRouter = require('./routes/config');
app.use('/api/config', configRouter);

const expensesRouter = require('./routes/expenses');
app.use('/api/expenses', expensesRouter);

const holdsRouter = require('./routes/holds');
app.use('/api/holds', holdsRouter);

const chatRouter = require('./routes/chat');
app.use('/api/ai/chat', chatRouter);

const parcelsRouter = require('./routes/parcels');
app.use('/api/parcels', parcelsRouter);


// Stores Network endpoint (Feature 2 — Save-The-Sale)
const STORES_NETWORK_FILE = path.join(__dirname, 'stores_network.json');
app.get('/api/stores/network', (req, res) => {
    try {
        const raw = fs.readFileSync(STORES_NETWORK_FILE, 'utf8');
        res.json(JSON.parse(raw));
    } catch (e) {
        res.json({ stores: [] });
    }
});


const GlobalNodeCache = require('node-cache');
const globalApiCache = new GlobalNodeCache({ stdTTL: 300 }); // 5 minutes cache for blazing fast tab switches

// Global Cache Middleware
app.use((req, res, next) => {
    const cacheEndpoints = [
        '/api/sales/overview',
        '/api/sales/history',
        '/api/sales/daily-month',
        '/api/analytics/hourly',
        '/api/analytics/monthly-products',
        '/api/inventory',
        '/api/inventory/dead-stock',
        '/api/customers/vip',
        '/api/customers/dormant',
        '/api/analytics/retention-radar',
        '/api/financials/pnl',
        '/api/analytics/wardrobe-profiles',
        '/api/financials/gst-summary',
        '/api/inventory/size-matrix',
        '/api/analytics/top-movers',
        '/api/sales/returns',
        '/api/broadcast/group',
        '/api/smart-bundles',
        '/api/reports/eod-summary',
        '/api/inventory/reorder-suggestions',
        '/api/inventory/stock-health',
        '/api/inventory/broken-sizes',
        '/api/inventory/dead-stock-aged',
        '/api/loyalty/leaderboard'
    ];

    if (req.method === 'GET' && cacheEndpoints.includes(req.path) && req.query.refresh !== 'true') {
        const key = req.originalUrl;
        const cachedResponse = globalApiCache.get(key);
        if (cachedResponse) {
            return res.json(cachedResponse);
        }
        
        const originalJson = res.json;
        res.json = function(body) {
            if (res.statusCode >= 200 && res.statusCode < 300 && body && !body.error) {
                globalApiCache.set(key, body);
            }
            return originalJson.call(this, body);
        };
        next();
    } else {
        next();
    }
});
// Serve the compiled frontend UI so it can be accessed on a phone via tunneling port 5000
const frontendPath = path.join(__dirname, '../cobb-ui/dist');
if (fs.existsSync(frontendPath)) {
    app.use(express.static(frontendPath, {
        setHeaders: (res, filePath) => {
            if (filePath.endsWith('.html')) {
                res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
                res.setHeader('Pragma', 'no-cache');
                res.setHeader('Expires', '0');
            }
        }
    }));
}

process.on('uncaughtException', (err) => {
    console.error('Unhandled Exception:', err);
    try {
        fs.appendFileSync(path.join(__dirname, 'backend_error.log'), `[${new Date().toISOString()}] Unhandled Exception: ${err.stack || err}\n`);
    } catch (e) { }
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
    try {
        fs.appendFileSync(path.join(__dirname, 'backend_error.log'), `[${new Date().toISOString()}] Unhandled Rejection: ${reason.stack || reason}\n`);
    } catch (e) { }
});

connectDB();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const getAiModel = (overrideModel) => {
    const target = overrideModel || process.env.GEMINI_MODEL || 'gemini-3.6-flash';
    try {
        return genAI.getGenerativeModel({ model: target });
    } catch (e) {
        return genAI.getGenerativeModel({ model: 'gemini-3.5-flash' });
    }
};

const multer = require('multer');
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir);
}
const upload = multer({ dest: uploadsDir });

let pythonProcess = null;
let pythonLogs = [];

let gatewayProcess = null;
let gatewayLogs = [];

const mapLoyalty = (customers) => {
    return customers.map(c => {
        let tier = 'Bronze';
        let nextTier = 'Silver';
        let threshold = 10000;
        const spend = c.LifetimeSpend || 0;
        
        if (spend >= 50000) {
            tier = 'Platinum';
            nextTier = null;
            threshold = null;
        } else if (spend >= 25000) {
            tier = 'Gold';
            nextTier = 'Platinum';
            threshold = 50000;
        } else if (spend >= 10000) {
            tier = 'Silver';
            nextTier = 'Gold';
            threshold = 25000;
        }

        return {
            ...c,
            loyaltyTier: tier,
            nextTier: nextTier,
            spendToNextTier: threshold ? threshold - spend : 0
        };
    });
};

function getListenerScriptPath() {
    const currentDirPath = path.join(__dirname, 'cobb_pos_listener.py');
    const parentDirPath = path.join(__dirname, '..', 'cobb_pos_listener.py');

    if (fs.existsSync(currentDirPath)) {
        return { scriptPath: currentDirPath, cwd: __dirname };
    } else if (fs.existsSync(parentDirPath)) {
        return { scriptPath: parentDirPath, cwd: path.join(__dirname, '..') };
    }
    return { scriptPath: currentDirPath, cwd: __dirname };
}


app.get('/api/sales/overview', async (req, res) => {
    try {
        const batchResult = await sql.query(`
            DECLARE @todayStart DATE = CAST(GETDATE() AS DATE);
            DECLARE @yesterdayStart DATE = DATEADD(day, -1, @todayStart);
            DECLARE @thisWeekStart DATE = DATEADD(day, 1 - DATEPART(dw, GETDATE()), @todayStart);
            DECLARE @lastWeekStart DATE = DATEADD(day, -7, @thisWeekStart);
            DECLARE @thisMonthStart DATE = DATEFROMPARTS(YEAR(@todayStart), MONTH(@todayStart), 1);
            DECLARE @nextMonthStart DATE = DATEADD(month, 1, @thisMonthStart);
            DECLARE @lastMonthStart DATE = DATEADD(month, -1, @thisMonthStart);

            SELECT 
                ISNULL(SUM(m.NET_AMOUNT), 0) as TotalSales, 
                COUNT(m.CM_ID) as BillCount,
                ISNULL(SUM(p.CASH_AMOUNT), 0) as CashAmount,
                ISNULL(SUM(p.CC_AMOUNT), 0) - ISNULL(SUM(ISNULL(w.UPI, 0) + ISNULL(w.[Paytm QR], 0) + ISNULL(w.Paytm, 0) + ISNULL(w.[PAYTM UPI], 0) + ISNULL(w.RazorpayUPI, 0)), 0) as CardAmount,
                ISNULL(SUM(ISNULL(w.UPI, 0) + ISNULL(w.[Paytm QR], 0) + ISNULL(w.Paytm, 0) + ISNULL(w.[PAYTM UPI], 0) + ISNULL(w.RazorpayUPI, 0)), 0) as UPIAmount,
                ISNULL(SUM(CASE WHEN m.DISCOUNT_AMOUNT > 0 THEN m.NET_AMOUNT ELSE 0 END), 0) as DiscountedSalesAmount,
                ISNULL(SUM(CASE WHEN ISNULL(m.DISCOUNT_AMOUNT, 0) = 0 THEN m.NET_AMOUNT ELSE 0 END), 0) as FullPriceSalesAmount
            FROM CMM01106 m WITH (NOLOCK)
            LEFT JOIN VW_BILL_PAYMODE p WITH (NOLOCK) ON m.CM_ID = p.MEMO_ID
            LEFT JOIN VW_WL_CASHMEMOLIST w WITH (NOLOCK) ON m.CM_ID = w.MEMO_ID
            WHERE m.CM_TIME >= @todayStart AND m.CANCELLED = 0;

            SELECT ISNULL(SUM(NET_AMOUNT), 0) as TotalSales, COUNT(CM_ID) as BillCount 
            FROM CMM01106 WITH (NOLOCK) 
            WHERE CM_TIME >= @yesterdayStart AND CM_TIME < @todayStart AND CANCELLED = 0;

            SELECT ISNULL(SUM(NET_AMOUNT), 0) as TotalSales, COUNT(CM_ID) as BillCount
            FROM CMM01106 WITH (NOLOCK)
            WHERE CANCELLED = 0 AND CM_TIME >= @thisWeekStart;

            SELECT ISNULL(SUM(NET_AMOUNT), 0) as TotalSales, COUNT(CM_ID) as BillCount
            FROM CMM01106 WITH (NOLOCK)
            WHERE CANCELLED = 0 AND CM_TIME >= @lastWeekStart AND CM_TIME < @thisWeekStart;

            SELECT ISNULL(SUM(NET_AMOUNT), 0) as TotalSales, COUNT(CM_ID) as BillCount
            FROM CMM01106 WITH (NOLOCK)
            WHERE CANCELLED = 0 AND CM_TIME >= @thisMonthStart AND CM_TIME < @nextMonthStart;

            SELECT ISNULL(SUM(NET_AMOUNT), 0) as TotalSales, COUNT(CM_ID) as BillCount
            FROM CMM01106 WITH (NOLOCK)
            WHERE CANCELLED = 0 AND CM_TIME >= @lastMonthStart AND CM_TIME < @thisMonthStart;
        `);

        const sets = batchResult.recordsets;
        const responseData = {
            today: sets[0]?.[0] || { TotalSales: 0, BillCount: 0, CashAmount: 0, CardAmount: 0, UPIAmount: 0 },
            yesterday: sets[1]?.[0] || { TotalSales: 0, BillCount: 0 },
            thisWeek: sets[2]?.[0] || { TotalSales: 0, BillCount: 0 },
            lastWeek: sets[3]?.[0] || { TotalSales: 0, BillCount: 0 },
            thisMonth: sets[4]?.[0] || { TotalSales: 0, BillCount: 0 },
            lastMonth: sets[5]?.[0] || { TotalSales: 0, BillCount: 0 }
        };
        
        res.json(responseData);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/sales/daily-month', async (req, res) => {
    try {
        const result = await sql.query(`
            SELECT 
                CAST(m.CM_TIME AS DATE) AS SaleDate,
                ISNULL(SUM(m.NET_AMOUNT), 0) AS TotalSales,
                ISNULL(SUM(p.CASH_AMOUNT), 0) AS CashAmount,
                ISNULL(SUM(p.CC_AMOUNT), 0) - ISNULL(SUM(ISNULL(w.UPI, 0) + ISNULL(w.[Paytm QR], 0) + ISNULL(w.Paytm, 0) + ISNULL(w.[PAYTM UPI], 0) + ISNULL(w.RazorpayUPI, 0)), 0) as CardAmount,
                ISNULL(SUM(ISNULL(w.UPI, 0) + ISNULL(w.[Paytm QR], 0) + ISNULL(w.Paytm, 0) + ISNULL(w.[PAYTM UPI], 0) + ISNULL(w.RazorpayUPI, 0)), 0) as UPIAmount
            FROM CMM01106 m WITH (NOLOCK)
            LEFT JOIN VW_BILL_PAYMODE p WITH (NOLOCK) ON m.CM_ID = p.MEMO_ID
            LEFT JOIN VW_WL_CASHMEMOLIST w WITH (NOLOCK) ON m.CM_ID = w.MEMO_ID
            WHERE m.CM_TIME >= DATEADD(month, -6, GETDATE()) 
              AND m.CANCELLED = 0
            GROUP BY CAST(m.CM_TIME AS DATE)
            ORDER BY SaleDate ASC
        `);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/analytics/hourly', async (req, res) => {
    try {
        const result = await sql.query(`
            SELECT 
                DATEPART(hour, CM_TIME) AS SaleHour,
                COUNT(CM_ID) AS TotalBills,
                SUM(NET_AMOUNT) AS TotalRevenue
            FROM CMM01106 WITH (NOLOCK)
            WHERE CM_TIME >= CAST(GETDATE() AS DATE) AND CANCELLED = 0
            GROUP BY DATEPART(hour, CM_TIME)
            ORDER BY SaleHour ASC
        `);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/analytics/monthly-products', async (req, res) => {
    try {
        const result = await sql.query(`
            SELECT 
                CONVERT(varchar(7), b.CM_TIME, 120) AS SaleMonth,
                ISNULL(f.SECTION_NAME, 'Uncategorized') AS ProductType,
                ISNULL(d.ARTICLE_NAME, 'General Article') AS ArticleName,
                SUM(a.QUANTITY) AS TotalUnitsSold,
                SUM(a.NET) AS TotalRevenue
            FROM CMD01106 a WITH (NOLOCK)
            JOIN CMM01106 b WITH (NOLOCK) ON b.CM_ID = a.CM_ID
            JOIN SKU c WITH (NOLOCK) ON a.PRODUCT_CODE = c.PRODUCT_CODE
            JOIN ARTICLE d WITH (NOLOCK) ON c.ARTICLE_CODE = d.ARTICLE_CODE
            LEFT JOIN SECTIOND e WITH (NOLOCK) ON d.SUB_SECTION_CODE = e.SUB_SECTION_CODE
            LEFT JOIN SECTIONM f WITH (NOLOCK) ON e.SECTION_CODE = f.SECTION_CODE
            WHERE b.CANCELLED = 0 AND b.CM_TIME >= DATEADD(month, -4, GETDATE())
            GROUP BY CONVERT(varchar(7), b.CM_TIME, 120), f.SECTION_NAME, d.ARTICLE_NAME
            ORDER BY SaleMonth DESC, TotalRevenue DESC
        `);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ===================================================================
// STOCK HEALTH TILES — Dashboard Bento Row 2
// ===================================================================

// 1. Broken Size Runs — styles where core sizes (32-40) are out but other sizes sit
app.get('/api/inventory/broken-sizes', async (req, res) => {
    try {
        const result = await sql.query(`
            ;WITH ArticleSizes AS (
                SELECT
                    s.article_no AS ArticleNo,
                    MAX(ISNULL(s.article_name, s.section_name + ' / ' + s.sub_section_name)) AS ArticleName,
                    MAX(ISNULL(s.section_name, 'Apparel')) AS Category,
                    ISNULL(s.para2_name, 'Standard') AS Size,
                    SUM(p.quantity_in_stock) AS SizeStock
                FROM PMT01106 p WITH (NOLOCK)
                INNER JOIN SKU_NAMES s WITH (NOLOCK) ON p.product_code = s.product_Code
                WHERE p.quantity_in_stock >= 0
                GROUP BY s.article_no, s.para2_name, s.article_name, s.section_name, s.sub_section_name
            ),
            ArticleTotals AS (
                SELECT
                    ArticleNo,
                    MAX(ArticleName) AS ArticleName,
                    MAX(Category) AS Category,
                    SUM(SizeStock) AS TotalStock,
                    COUNT(DISTINCT Size) AS TotalSizeCount,
                    SUM(CASE WHEN Size IN ('30','32','34','36','38','40','S','M','L','XL') AND SizeStock = 0 THEN 1 ELSE 0 END) AS CoreSizesOut,
                    SUM(CASE WHEN Size IN ('30','32','34','36','38','40','S','M','L','XL') THEN 1 ELSE 0 END) AS CoreSizesTotal,
                    SUM(CASE WHEN SizeStock > 0 THEN 1 ELSE 0 END) AS SizesInStock,
                    SUM(CASE WHEN SizeStock = 0 THEN 1 ELSE 0 END) AS SizesOutOfStock
                FROM ArticleSizes
                GROUP BY ArticleNo
                HAVING SUM(SizeStock) > 0
            )
            SELECT TOP 100
                at2.ArticleNo,
                at2.ArticleName,
                at2.Category,
                at2.TotalStock,
                at2.TotalSizeCount,
                at2.CoreSizesOut,
                at2.CoreSizesTotal,
                at2.SizesInStock,
                at2.SizesOutOfStock
            FROM ArticleTotals at2
            WHERE at2.CoreSizesOut > 0 AND at2.CoreSizesTotal > 0
            ORDER BY at2.CoreSizesOut DESC, at2.TotalStock DESC
        `);
        res.json(result.recordset);
    } catch (err) {
        console.error('Broken sizes error:', err);
        res.status(500).json({ error: err.message });
    }
});

// 2. Dead Stock with Ageing — items with stock but no sales in 60+/90+ days
app.get('/api/inventory/dead-stock-aged', async (req, res) => {
    try {
        const result = await sql.query(`
            ;WITH LastSale AS (
                SELECT
                    s.article_no AS ArticleNo,
                    MAX(m.CM_TIME) AS LastSaleDate
                FROM CMD01106 d WITH (NOLOCK)
                JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
                JOIN SKU_NAMES s WITH (NOLOCK) ON d.PRODUCT_CODE = s.product_Code
                WHERE m.CANCELLED = 0
                GROUP BY s.article_no
            ),
            StockSummary AS (
                SELECT
                    s.article_no AS ArticleNo,
                    MAX(ISNULL(s.article_name, s.section_name + ' / ' + s.sub_section_name)) AS ArticleName,
                    MAX(ISNULL(s.section_name, 'Apparel')) AS Category,
                    SUM(p.quantity_in_stock) AS TotalStock,
                    COUNT(DISTINCT s.product_Code) AS SkuCount
                FROM PMT01106 p WITH (NOLOCK)
                INNER JOIN SKU_NAMES s WITH (NOLOCK) ON p.product_code = s.product_Code
                WHERE p.quantity_in_stock > 0
                GROUP BY s.article_no
            )
            SELECT TOP 200
                ss.ArticleNo,
                ss.ArticleName,
                ss.Category,
                ss.TotalStock,
                ss.SkuCount,
                ls.LastSaleDate,
                CASE WHEN ls.LastSaleDate IS NULL THEN 999
                     ELSE DATEDIFF(day, ls.LastSaleDate, GETDATE()) END AS DaysSinceLastSale,
                CASE
                    WHEN ls.LastSaleDate IS NULL THEN 'never_sold'
                    WHEN DATEDIFF(day, ls.LastSaleDate, GETDATE()) >= 90 THEN '90plus'
                    WHEN DATEDIFF(day, ls.LastSaleDate, GETDATE()) >= 60 THEN '60plus'
                    WHEN DATEDIFF(day, ls.LastSaleDate, GETDATE()) >= 30 THEN '30plus'
                    ELSE 'active'
                END AS AgeingBucket
            FROM StockSummary ss
            LEFT JOIN LastSale ls ON ss.ArticleNo = ls.ArticleNo
            WHERE ls.LastSaleDate IS NULL
               OR DATEDIFF(day, ls.LastSaleDate, GETDATE()) >= 30
            ORDER BY
                CASE WHEN ls.LastSaleDate IS NULL THEN 999
                     ELSE DATEDIFF(day, ls.LastSaleDate, GETDATE()) END DESC,
                ss.TotalStock DESC
        `);
        res.json(result.recordset);
    } catch (err) {
        console.error('Dead stock aged error:', err);
        res.status(500).json({ error: err.message });
    }
});

// 3. Stock Health Summary — combined quick-glance data for all 3 dashboard tiles
app.get('/api/inventory/stock-health', async (req, res) => {
    try {
        // Broken Size Runs count
        const brokenResult = await sql.query(`
            ;WITH ArticleSizes AS (
                SELECT
                    s.article_no AS ArticleNo,
                    ISNULL(s.para2_name, 'Standard') AS Size,
                    SUM(p.quantity_in_stock) AS SizeStock
                FROM PMT01106 p WITH (NOLOCK)
                INNER JOIN SKU_NAMES s WITH (NOLOCK) ON p.product_code = s.product_Code
                WHERE p.quantity_in_stock >= 0
                GROUP BY s.article_no, s.para2_name
            )
            SELECT
                COUNT(DISTINCT ArticleNo) AS BrokenRunCount
            FROM (
                SELECT
                    ArticleNo,
                    SUM(CASE WHEN Size IN ('30','32','34','36','38','40','S','M','L','XL') AND SizeStock = 0 THEN 1 ELSE 0 END) AS CoreOut,
                    SUM(CASE WHEN Size IN ('30','32','34','36','38','40','S','M','L','XL') THEN 1 ELSE 0 END) AS CoreTotal,
                    SUM(SizeStock) AS TotalStock
                FROM ArticleSizes
                GROUP BY ArticleNo
                HAVING SUM(SizeStock) > 0
                   AND SUM(CASE WHEN Size IN ('30','32','34','36','38','40','S','M','L','XL') AND SizeStock = 0 THEN 1 ELSE 0 END) > 0
                   AND SUM(CASE WHEN Size IN ('30','32','34','36','38','40','S','M','L','XL') THEN 1 ELSE 0 END) > 0
            ) x
        `);

        // Dead stock ageing summary
        const deadResult = await sql.query(`
            ;WITH LastSale AS (
                SELECT
                    s.article_no AS ArticleNo,
                    MAX(m.CM_TIME) AS LastSaleDate
                FROM CMD01106 d WITH (NOLOCK)
                JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
                JOIN SKU_NAMES s WITH (NOLOCK) ON d.PRODUCT_CODE = s.product_Code
                WHERE m.CANCELLED = 0
                GROUP BY s.article_no
            ),
            StockSummary AS (
                SELECT
                    s.article_no AS ArticleNo,
                    SUM(p.quantity_in_stock) AS TotalStock
                FROM PMT01106 p WITH (NOLOCK)
                INNER JOIN SKU_NAMES s WITH (NOLOCK) ON p.product_code = s.product_Code
                WHERE p.quantity_in_stock > 0
                GROUP BY s.article_no
            )
            SELECT
                SUM(CASE WHEN DATEDIFF(day, ls.LastSaleDate, GETDATE()) >= 90 OR ls.LastSaleDate IS NULL THEN ss.TotalStock ELSE 0 END) AS Units90Plus,
                SUM(CASE WHEN DATEDIFF(day, ls.LastSaleDate, GETDATE()) >= 60 OR ls.LastSaleDate IS NULL THEN ss.TotalStock ELSE 0 END) AS Units60Plus,
                SUM(CASE WHEN DATEDIFF(day, ls.LastSaleDate, GETDATE()) >= 30 OR ls.LastSaleDate IS NULL THEN ss.TotalStock ELSE 0 END) AS Units30Plus,
                COUNT(CASE WHEN DATEDIFF(day, ls.LastSaleDate, GETDATE()) >= 90 OR ls.LastSaleDate IS NULL THEN 1 END) AS Articles90Plus,
                COUNT(CASE WHEN DATEDIFF(day, ls.LastSaleDate, GETDATE()) >= 60 OR ls.LastSaleDate IS NULL THEN 1 END) AS Articles60Plus,
                SUM(ss.TotalStock) AS TotalStockUnits
            FROM StockSummary ss
            LEFT JOIN LastSale ls ON ss.ArticleNo = ls.ArticleNo
            WHERE ls.LastSaleDate IS NULL OR DATEDIFF(day, ls.LastSaleDate, GETDATE()) >= 30
        `);

        // Reorder alerts — fast movers with < 2 weeks of cover
        const reorderResult = await sql.query(`
            ;WITH SalesVelocity AS (
                SELECT
                    s.article_no AS ArticleNo,
                    MAX(ISNULL(s.article_name, s.section_name)) AS ArticleName,
                    SUM(d.QUANTITY) AS UnitsSold90d,
                    CAST(SUM(d.QUANTITY) AS FLOAT) / 13.0 AS AvgWeeklySales
                FROM CMD01106 d WITH (NOLOCK)
                JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
                JOIN SKU_NAMES s WITH (NOLOCK) ON d.PRODUCT_CODE = s.product_Code
                WHERE m.CANCELLED = 0 AND m.CM_TIME >= DATEADD(day, -90, GETDATE())
                GROUP BY s.article_no
                HAVING SUM(d.QUANTITY) > 0
            ),
            CurrentStock AS (
                SELECT
                    s.article_no AS ArticleNo,
                    SUM(p.quantity_in_stock) AS CurrentStock
                FROM PMT01106 p WITH (NOLOCK)
                JOIN SKU_NAMES s WITH (NOLOCK) ON p.product_code = s.product_Code
                WHERE p.quantity_in_stock >= 0
                GROUP BY s.article_no
            )
            SELECT
                COUNT(*) AS ReorderAlertCount,
                SUM(CASE WHEN ISNULL(cs.CurrentStock, 0) = 0 THEN 1 ELSE 0 END) AS ZeroStockCount,
                SUM(sv.UnitsSold90d) AS TotalVelocityUnits
            FROM SalesVelocity sv
            LEFT JOIN CurrentStock cs ON sv.ArticleNo = cs.ArticleNo
            WHERE CASE WHEN sv.AvgWeeklySales > 0
                       THEN ISNULL(cs.CurrentStock, 0) / sv.AvgWeeklySales
                       ELSE 99 END < 2
        `);

        const broken = brokenResult.recordset[0] || {};
        const dead = deadResult.recordset[0] || {};
        const reorder = reorderResult.recordset[0] || {};

        res.json({
            brokenSizeRuns: {
                count: broken.BrokenRunCount || 0
            },
            deadStock: {
                units90Plus: dead.Units90Plus || 0,
                units60Plus: dead.Units60Plus || 0,
                units30Plus: dead.Units30Plus || 0,
                articles90Plus: dead.Articles90Plus || 0,
                articles60Plus: dead.Articles60Plus || 0,
                totalStockUnits: dead.TotalStockUnits || 0
            },
            reorderAlerts: {
                count: reorder.ReorderAlertCount || 0,
                zeroStock: reorder.ZeroStockCount || 0,
                totalVelocityUnits: reorder.TotalVelocityUnits || 0
            }
        });
    } catch (err) {
        console.error('Stock health summary error:', err);
        res.status(500).json({ error: err.message });
    }
});


app.get('/api/inventory/quick-scan', async (req, res) => {
    try {
        const query = (req.query.q || '').trim();
        if (!query) {
            return res.json({ success: false, message: 'Query is required' });
        }

        const findReq = new sql.Request();
        findReq.input('q', sql.NVarChar, query);
        
        const matchRes = await findReq.query(`
            SELECT TOP 1 s.article_no, ISNULL(s.article_name, s.section_name) as itemName, s.section_name as sectionName
            FROM SKU_NAMES s WITH (NOLOCK)
            WHERE s.product_Code = @q 
               OR s.article_no = @q 
               OR s.VENDOR_EAN_NO = @q
               OR s.article_no LIKE @q + '%'
        `);

        if (!matchRes.recordset || matchRes.recordset.length === 0) {
            return res.json({ success: false, message: `No item found matching "${query}"` });
        }

        const matchedArticle = matchRes.recordset[0].article_no;
        const matchedItemName = matchRes.recordset[0].itemName;
        const matchedSection = matchRes.recordset[0].sectionName;

        const variantReq = new sql.Request();
        variantReq.input('art', sql.NVarChar, matchedArticle);

        const variantsRes = await variantReq.query(`
            SELECT 
                s.product_Code as barcode,
                s.article_no as articleNo,
                ISNULL(s.article_name, s.section_name) as itemName,
                ISNULL(s.para1_name, 'Standard') as color,
                ISNULL(s.para2_name, 'Standard') as size,
                ISNULL(s.para2_order, 99) as sizeOrder,
                ISNULL(s.mrp, 0) as mrp,
                ISNULL(p.quantity_in_stock, 0) as stock
            FROM SKU_NAMES s WITH (NOLOCK)
            LEFT JOIN PMT01106 p WITH (NOLOCK) ON s.product_Code = p.product_code
            WHERE s.article_no = @art
            ORDER BY s.para2_order, s.para2_name
        `);

        const rows = variantsRes.recordset || [];
        const totalStock = rows.reduce((sum, r) => sum + Math.max(0, r.stock || 0), 0);
        const mrp = rows[0]?.mrp || 0;
        const color = rows[0]?.color || '';

        const sizeMap = {};
        rows.forEach(r => {
            const sz = r.size;
            if (!sizeMap[sz]) {
                sizeMap[sz] = { size: sz, stock: 0, barcode: r.barcode };
            }
            sizeMap[sz].stock += Math.max(0, r.stock || 0);
        });

        const sizes = Object.values(sizeMap);

        return res.json({
            success: true,
            articleNo: matchedArticle,
            itemName: matchedItemName,
            sectionName: matchedSection,
            color,
            mrp,
            totalStock,
            sizes,
            variants: rows
        });
    } catch (err) {
        console.error('[QuickScan API Error]', err);
        return res.status(500).json({ success: false, error: err.message });
    }
});

app.get('/api/inventory/dead-stock', async (req, res) => {
    try {
        const result = await sql.query(`
            SELECT TOP 1000
                s.article_no AS ArticleNo,
                MAX(s.section_name + ' / ' + s.sub_section_name) AS ItemName,
                COUNT(s.product_Code) as SkuCount,
                '' as SkuDetails
            FROM PMT01106 p WITH (NOLOCK)
            INNER JOIN SKU_NAMES s WITH (NOLOCK) ON p.product_code = s.product_Code
            WHERE p.quantity_in_stock > 0
            GROUP BY s.article_no
            ORDER BY SkuCount DESC
        `);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

let cachedTips = null;
let cacheTimestamp = 0;
const CACHE_DURATION = 15 * 60 * 1000; // 15 minutes

app.post('/api/ai/demand-forecasts', async (req, res) => {
    // Check if the request is auto-fetch on mount or a forced refresh
    const isForceRefresh = req.body && (req.body.refresh === true || Object.keys(req.body).length > 0);
    const now = Date.now();

    let deadStockSample = null;
    let lowStockSample = null;
    try {
        deadStockSample = await sql.query(`
            SELECT TOP 2
                s.article_no AS ArticleNo,
                ISNULL(s.article_name, s.section_name) AS ItemName,
                p.quantity_in_stock AS CurrentStock
            FROM PMT01106 p
            INNER JOIN SKU_NAMES s ON p.product_code = s.product_Code
            WHERE p.quantity_in_stock >= 3
              AND p.product_code NOT IN (
                  SELECT DISTINCT d.PRODUCT_CODE 
                  FROM CMD01106 d WITH (NOLOCK)
                  INNER JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
                  WHERE m.CM_TIME >= DATEADD(day, -60, GETDATE()) AND m.CANCELLED = 0
              )
            ORDER BY p.quantity_in_stock DESC
        `);

        lowStockSample = await sql.query(`
            SELECT TOP 2
                s.article_no AS ArticleNo,
                ISNULL(s.article_name, s.section_name) AS ItemName,
                ISNULL(s.para2_name, 'Standard') AS Size,
                p.quantity_in_stock AS CurrentStock
            FROM PMT01106 p
            INNER JOIN SKU_NAMES s ON p.product_code = s.product_Code
            WHERE p.quantity_in_stock BETWEEN 1 AND 3
            ORDER BY p.quantity_in_stock ASC
        `);
    } catch (dbErr) {
        console.error("Database query failed during AI prep:", dbErr);
    }

    const deadItemsText = (deadStockSample && deadStockSample.recordset.length > 0)
        ? deadStockSample.recordset.map(i => `${i.ArticleNo} (${i.ItemName}, ${i.CurrentStock} units left)`).join("; ")
        : "No stagnant items found";

    const lowItemsText = (lowStockSample && lowStockSample.recordset.length > 0)
        ? lowStockSample.recordset.map(i => `${i.ArticleNo} (${i.ItemName}, Size: ${i.Size}, ${i.CurrentStock} units)`).join("; ")
        : "All core sizes adequately stocked";

    // Setup fallback tips in case Gemini API is blocked/429'd
    const getFallbackTips = () => [
        {
            tag: "Cobb Supplier Order",
            tip: (lowStockSample && lowStockSample.recordset.length > 0)
                ? `Restock low item ${lowStockSample.recordset[0].ArticleNo} (${lowStockSample.recordset[0].ItemName}, ${lowStockSample.recordset[0].CurrentStock} left). Request fresh Cobb polo tees.`
                : "Low stock alert: Restock core size items and order trending Cobb smart-fit shirts from the main warehouse."
        },
        {
            tag: "Dead Stock Pivot",
            tip: (deadStockSample && deadStockSample.recordset.length > 0)
                ? `Style stagnant article ${deadStockSample.recordset[0].ArticleNo} by pairing it with trending Cobb Straight-Fit Jeans on the front display.`
                : "Style slow-moving items by displaying them paired with new season Cobb lightweight jackets."
        },
        {
            tag: "Display Strategy",
            tip: "Mannequin Alert: Arrange mannequins near the storefront highlighting Cobb Ultra-Fit Trousers and Cargo summer shorts."
        },
        {
            tag: "Cross-Sell Playbook",
            tip: "Upsell guideline: Direct floor staff to pair Slim-Fit Formal Shirts with Ultra-Fit Trousers for a complete outfit purchase."
        }
    ];

    if (!isForceRefresh && cachedTips && (now - cacheTimestamp < CACHE_DURATION)) {
        console.log('[AI CACHE] Returning cached demand-forecasts tips');
        return res.json({ tips: cachedTips });
    }

    try {
        const model = getAiModel();

        const prompt = `
        You are an expert menswear retail strategist exclusively for a "Cobb Italy" (Cobb Apparels) franchise store in Haryana.
        
        Current Live Inventory Context:
        - Stagnant Dead Stock (Unsold 60+ days): ${deadItemsText}
        - Critically Low Stock (1 to 3 units left): ${lowItemsText}
        
        BRAND-SPECIFIC CATALOG TRENDS (Only suggest these Cobb lines):
        1. "T-Shirt Shift": High demand for Cobb's Color-Block Polo Neck T-Shirts and Oversized Round Neck Tees.
        2. "Bottomwear": Shift towards Cobb Straight-Fit and Boot-Cut Premium Jeans, and Six-Pocket Cargo Summer Lowers.
        3. "Smart Layering": High demand for Cobb Smart-Fit Formal Shirts paired with Ultra-Fit Formal Trousers and Chinos in Khaki, Olive, and Peach.
        4. "Autumn Transition": Push Cobb Shackets, Co-ord Sets, and Lightweight Jackets.

        Generate exactly 4 actionable daily tips for the store manager as a JSON array of objects.
        
        REQUIRED TIP BREAKDOWN:
        - Tip 1: "Cobb Supplier Order" -> Look at the Low Stock items above. Tell the manager to restock these AND specifically request the trending Cobb lines (e.g. Boot-Cut Jeans, Color-Block Polos) from the Cobb warehouse.
        - Tip 2: "Dead Stock Pivot" -> Tell the staff how to style one of our specific Dead Stock items (${deadItemsText}) by pairing it with a trending Cobb item (like a Shacket or Smart-Fit shirt) to make it sell.
        - Tip 3: "Display Strategy" -> A quick tip on arranging mannequins to highlight Cobb's Ultra-Fit Trousers or Cargo Lowers.
        - Tip 4: "Cross-Sell Playbook" -> Natural item pairing advice using Cobb terminology (e.g. "Pair Slim-Fit Formal Shirts with Ultra-Fit Trousers").
        
        CRITICAL RULES:
        - DO NOT mention generic trends unless stated above. Stick to Cobb brand terminology.
        - DO NOT mention discounts, coupons, sales, or markdown percentages.
        - Format the response strictly as a raw JSON array with keys: "tag" and "tip".
        - Each tip must be under 30 words.
        - Output ONLY valid raw JSON. No markdown blocks.
        `;

        const result = await model.generateContent(prompt);
        let rawText = result.response.text().trim();

        if (rawText.startsWith('```json')) {
            rawText = rawText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
        } else if (rawText.startsWith('```')) {
            rawText = rawText.replace(/^```\s*/, '').replace(/\s*```$/, '');
        }

        const tips = JSON.parse(rawText);

        // Cache the tips
        cachedTips = tips;
        cacheTimestamp = now;

        res.json({ tips });
    } catch (err) {
        console.warn("AI Database Forecast Error, falling back to local tips:", err.message);
        const tips = cachedTips || getFallbackTips();
        res.json({ tips, isFallback: true });
    }
});

app.post('/api/ai/persona', async (req, res) => {
    const { purchases } = req.body;
    try {
        const model = getAiModel();
        const prompt = `
        Analyze the following recent clothing purchases from a male customer at a menswear store:
        "${purchases}"
        
        Classify this customer's style into exactly ONE of the following persona tags:
        - Corporate Professional
        - Weekend Casual
        - Denim Enthusiast
        - Festive / Traditional
        - Trendsetter
        - Essentials Buyer
        
        Output ONLY the tag name. Do not include quotes or any other text.
        `;
        const result = await model.generateContent(prompt);
        res.json({ persona: result.response.text().trim() });
    } catch (err) {
        console.warn("AI Persona Classify Error, falling back to local classifier:", err.message);
        const p = (purchases || '').toLowerCase();
        let fallbackPersona = "Essentials Buyer";
        if (p.includes('suit') || p.includes('formal') || p.includes('blazer') || p.includes('trouser') || p.includes('shirt')) {
            fallbackPersona = "Corporate Professional";
        } else if (p.includes('jean') || p.includes('denim')) {
            fallbackPersona = "Denim Enthusiast";
        } else if (p.includes('cargo') || p.includes('tshirt') || p.includes('t-shirt') || p.includes('shorts') || p.includes('lower')) {
            fallbackPersona = "Weekend Casual";
        } else if (p.includes('shacket') || p.includes('jacket') || p.includes('oversized') || p.includes('hoodie')) {
            fallbackPersona = "Trendsetter";
        } else if (p.includes('kurta') || p.includes('sherwani') || p.includes('traditional') || p.includes('nehru')) {
            fallbackPersona = "Festive / Traditional";
        }
        res.json({ persona: fallbackPersona, isFallback: true });
    }
});

app.post('/api/ai/outfit-matcher', async (req, res) => {
    const { deadStockItem } = req.body;
    try {
        const model = getAiModel();
        const prompt = `
        You are an expert fashion stylist for Cobb Pundri menswear.
        We have this slow-moving item in our inventory: "${deadStockItem}".
        
        Write a short, engaging WhatsApp message promoting this item as the "Style of the Week". 
        Pair it conceptually with a popular basic (like classic blue jeans, navy chinos, or a clean white tee) to show the customer how to wear it perfectly.
        
        CRITICAL RULE: DO NOT MENTION ANY DISCOUNTS OR SALES. Focus purely on the styling and invite them to the store to try the look. Keep it under 50 words. Sign off as "Parbhat Goyal, Cobb Pundri".
        `;
        const result = await model.generateContent(prompt);
        res.json({ message: result.response.text() });
    } catch (err) {
        console.warn("AI Outfit Matcher Error, falling back to local copy:", err.message);
        const item = deadStockItem || "Cobb Premium Menswear";
        const fallbackMsg = `Style of the Week: Elevate your casual wardrobe with the ${item}. Pair it conceptually with classic blue jeans, navy chinos, or a clean white tee for an effortless fit. Visit us at Cobb Pundri to try it on! - Parbhat Goyal, Cobb Pundri`;
        res.json({ message: fallbackMsg, isFallback: true });
    }
});

app.post('/api/ai/smart-coordinate', async (req, res) => {
    const { items, customerName } = req.body;
    try {
        const model = getAiModel();
        const prompt = `
        You are an expert fashion stylist for Cobb Pundri menswear.
        Customer ${customerName || 'Valued Customer'} just bought these items: ${items.join(', ')}.
        
        Suggest 1 or 2 matching items from a menswear collection (like a belt, specific shoes, or a jacket) that perfectly complete this outfit.
        Write a short, friendly WhatsApp message (under 50 words) suggesting they add these to their wardrobe on their next visit. 
        Do not mention discounts. Sign off as "Parbhat Goyal, Cobb Pundri".
        `;
        const result = await model.generateContent(prompt);
        res.json({ message: result.response.text() });
    } catch (err) {
        console.warn("AI Smart Coordinate Error:", err.message);
        const fallbackMsg = `Hey ${customerName || 'Valued Customer'}, we hope you love your new items! To complete the look, we highly recommend pairing them with our premium leather belts or a smart casual jacket. Drop by soon! - Parbhat Goyal, Cobb Pundri`;
        res.json({ message: fallbackMsg, isFallback: true });
    }
});

app.post('/api/ai/campaign-builder', async (req, res) => {
    const { event, audience } = req.body;
    try {
        const model = getAiModel();
        const prompt = `
        You are the Marketing Director for Cobb Pundri, a premium menswear franchise in Haryana.
        
        Upcoming Campaign/Event: ${event}
        Target Audience Segment: ${audience}
        
        Write a highly engaging WhatsApp broadcast message to invite this specific audience to the store for this event/season.
        
        CRITICAL RULE: DO NOT OFFER ANY DISCOUNTS, PROMO CODES, OR PERCENTAGES OFF. You must strictly abide by franchise standard pricing. Do not mention specific prices.
        
        Make it sound exclusive and exciting. Keep it under 60 words. Use emojis appropriately. Sign off as "Parbhat Goyal, Cobb Pundri".
        `;
        const result = await model.generateContent(prompt);
        res.json({ message: result.response.text() });
    } catch (err) {
        console.warn("AI Campaign Builder Error, falling back to local copy:", err.message);
        const fallbackMsg = `Exclusive Store Alert: Join us at Cobb Pundri for our latest ${event || 'New Season Showcase'}. Specially designed for our valued ${audience || 'premium customers'}, check out our latest fits and fresh catalog additions. See you at the store! - Parbhat Goyal, Cobb Pundri`;
        res.json({ message: fallbackMsg, isFallback: true });
    }
});

app.post('/api/campaigns/generate', async (req, res) => {
    const { customerName, pastPurchases, type, sizes } = req.body;
    try {
        const model = getAiModel();

        let objective = "";
        if (type === 'cross-sell') {
            objective = "Acting as a personal stylist, suggest a matching Cobb Apparels item from our new collection that pairs perfectly with their past purchases.";
        } else if (type === 'size-alert') {
            objective = `Enthusiastically let them know we just received a fresh stock of Cobb arrivals specifically in their preferred sizes (${sizes}).`;
        } else if (type === 'dormant') {
            objective = "Write a warm, polite 'we miss you' message. Mention the new season's collection and invite them to stop by to check out the new Cobb fits.";
        } else if (type === 'vip') {
            objective = "Write a highly personalized, premium white-glove thank you message. Express genuine gratitude for them being one of our top Cobb customers.";
        }

        const prompt = `
        You are an expert retail marketer for Cobb Pundri, a men's clothing franchise in Haryana.
        
        CRITICAL RULE: DO NOT OFFER ANY DISCOUNTS, SALES, OFFERS, OR PERCENTAGES OFF. You are a franchise and must strictly abide by standard pricing. Do not mention specific prices.
        
        Customer Name: ${customerName}
        Past Purchases: ${pastPurchases}
        
        Objective: ${objective}
        
        Write a short, engaging WhatsApp message (under 50 words). Keep it friendly, professional, and natural. Do not use hashtags.
        Sign off as "Parbhat Goyal, Cobb Pundri".
        `;
        const result = await model.generateContent(prompt);
        res.json({ message: result.response.text() });
    } catch (err) {
        console.warn("AI Campaign Generator Error, falling back to local copy:", err.message);
        const name = customerName || "there";
        let fallbackMsg = `Hi ${name}, as one of our VIP customers, we invite you to explore the latest arrivals at Cobb Pundri. Elevate your wardrobe with the new season fits! - Parbhat Goyal, Cobb Pundri`;

        if (type === 'cross-sell') {
            fallbackMsg = `Hi ${name}! We hope you liked your recent purchases at Cobb. Based on your style, we suggest pairing them with our new collection of shirts and jeans. Stop by Cobb Pundri to try the look! - Parbhat Goyal, Cobb Pundri`;
        } else if (type === 'size-alert') {
            fallbackMsg = `Hi ${name}! Quick alert: We just received a fresh stock of new season Cobb fits in your sizes (${sizes || 'L/XL/32/34'}). Drop by Cobb Pundri to grab them before they're sold out! - Parbhat Goyal, Cobb Pundri`;
        } else if (type === 'dormant') {
            fallbackMsg = `Hi ${name}, we haven't seen you at Cobb Pundri in a while! Our fresh autumn collection is now live. We'd love to help you find your next look - hope to see you soon! - Parbhat Goyal, Cobb Pundri`;
        }
        res.json({ message: fallbackMsg, isFallback: true });
    }
});

app.get('/api/customers/vip', async (req, res) => {
    try {
        const result = await sql.query(`
            SELECT TOP 50 
                A.CUSTOMER_CODE as Phone, 
                B.CUSTOMER_FNAME as FirstName, 
                B.CUSTOMER_LNAME as LastName, 
                SUM(A.NET_AMOUNT) as LifetimeSpend, 
                COUNT(A.CM_ID) as TotalBills,
                CONVERT(varchar, MAX(A.CM_TIME), 126) as LastVisit
            FROM CMM01106 A WITH (NOLOCK)
            JOIN CUSTDYM B WITH (NOLOCK) ON B.CUSTOMER_CODE = A.CUSTOMER_CODE
            WHERE A.CANCELLED = 0 AND A.CUSTOMER_CODE IS NOT NULL AND LEN(A.CUSTOMER_CODE) >= 10
            GROUP BY A.CUSTOMER_CODE, B.CUSTOMER_FNAME, B.CUSTOMER_LNAME
            ORDER BY LifetimeSpend DESC
        `);
        res.json(mapLoyalty(result.recordset));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/customers/search', async (req, res) => {
    try {
        const { q } = req.query;
        if (!q) return res.json([]);
        const result = await sql.query`
            SELECT TOP 50 
                A.CUSTOMER_CODE as Phone, 
                B.CUSTOMER_FNAME as FirstName, 
                B.CUSTOMER_LNAME as LastName, 
                SUM(A.NET_AMOUNT) as LifetimeSpend, 
                COUNT(A.CM_ID) as TotalBills,
                CONVERT(varchar, MAX(A.CM_TIME), 126) as LastVisit
            FROM CMM01106 A WITH (NOLOCK)
            JOIN CUSTDYM B WITH (NOLOCK) ON B.CUSTOMER_CODE = A.CUSTOMER_CODE
            WHERE A.CANCELLED = 0 
              AND A.CUSTOMER_CODE IS NOT NULL 
              AND LEN(A.CUSTOMER_CODE) >= 10
              AND (
                  B.CUSTOMER_FNAME LIKE '%' + ${q} + '%' OR 
                  B.CUSTOMER_LNAME LIKE '%' + ${q} + '%' OR 
                  A.CUSTOMER_CODE LIKE '%' + ${q} + '%' OR
                  LTRIM(RTRIM(ISNULL(B.CUSTOMER_FNAME, '') + ' ' + ISNULL(B.CUSTOMER_LNAME, ''))) LIKE '%' + ${q} + '%'
              )
            GROUP BY A.CUSTOMER_CODE, B.CUSTOMER_FNAME, B.CUSTOMER_LNAME
            ORDER BY LifetimeSpend DESC
        `;
        res.json(mapLoyalty(result.recordset));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/customers/dormant', async (req, res) => {
    try {
        const result = await sql.query(`
            SELECT TOP 50 
                A.CUSTOMER_CODE as Phone, 
                B.CUSTOMER_FNAME as FirstName, 
                B.CUSTOMER_LNAME as LastName, 
                SUM(A.NET_AMOUNT) as LifetimeSpend, 
                DATEDIFF(day, MAX(A.CM_TIME), GETDATE()) as DaysSinceLastVisit
            FROM CMM01106 A WITH (NOLOCK)
            JOIN CUSTDYM B WITH (NOLOCK) ON B.CUSTOMER_CODE = A.CUSTOMER_CODE
            WHERE A.CANCELLED = 0 AND A.CUSTOMER_CODE IS NOT NULL AND LEN(A.CUSTOMER_CODE) >= 10
            GROUP BY A.CUSTOMER_CODE, B.CUSTOMER_FNAME, B.CUSTOMER_LNAME
            HAVING DATEDIFF(day, MAX(A.CM_TIME), GETDATE()) > 60
            ORDER BY LifetimeSpend DESC
        `);
        res.json(mapLoyalty(result.recordset));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/customers/segment', async (req, res) => {
    const { segment } = req.body;
    try {
        let query = '';
        if (segment === 'All VIP Customers') {
            query = `SELECT DISTINCT TOP 50 CUSTOMER_CODE as Phone, CUSTOMER_FNAME as FirstName FROM VW_CASHMEMO_PRINT_MST WITH (NOLOCK) WHERE CANCELLED = 0 AND CUSTOMER_CODE IS NOT NULL AND LEN(CUSTOMER_CODE) >= 10 ORDER BY CM_TIME DESC`;
        } else if (segment === 'Dormant Customers') {
            query = `SELECT DISTINCT TOP 50 CUSTOMER_CODE as Phone, CUSTOMER_FNAME as FirstName FROM VW_CASHMEMO_PRINT_MST WITH (NOLOCK) WHERE CANCELLED = 0 AND CUSTOMER_CODE IS NOT NULL AND LEN(CUSTOMER_CODE) >= 10 GROUP BY CUSTOMER_CODE, CUSTOMER_FNAME HAVING DATEDIFF(day, MAX(CM_TIME), GETDATE()) > 60`;
        } else if (segment === 'Formal / Suit Buyers') {
            query = `SELECT DISTINCT TOP 50 m.CUSTOMER_CODE as Phone, m.CUSTOMER_FNAME as FirstName FROM VW_CASHMEMO_PRINT_MST m WITH (NOLOCK) INNER JOIN VW_CASHMEMO_PRINT_DET d WITH (NOLOCK) ON m.CM_ID = d.CM_ID WHERE m.CANCELLED = 0 AND m.CUSTOMER_CODE IS NOT NULL AND LEN(m.CUSTOMER_CODE) >= 10 AND (d.SECTION_NAME LIKE '%Formal%' OR d.SECTION_NAME LIKE '%Trouser%' OR d.ARTICLE_NAME LIKE '%Suit%')`;
        } else if (segment === 'Denim Enthusiasts') {
            query = `SELECT DISTINCT TOP 50 m.CUSTOMER_CODE as Phone, m.CUSTOMER_FNAME as FirstName FROM VW_CASHMEMO_PRINT_MST m WITH (NOLOCK) INNER JOIN VW_CASHMEMO_PRINT_DET d WITH (NOLOCK) ON m.CM_ID = d.CM_ID WHERE m.CANCELLED = 0 AND m.CUSTOMER_CODE IS NOT NULL AND LEN(m.CUSTOMER_CODE) >= 10 AND (d.SECTION_NAME LIKE '%Jeans%' OR d.SECTION_NAME LIKE '%Denim%')`;
        } else {
            query = `SELECT DISTINCT TOP 10 CUSTOMER_CODE as Phone, CUSTOMER_FNAME as FirstName FROM VW_CASHMEMO_PRINT_MST WITH (NOLOCK) WHERE CANCELLED = 0 AND CUSTOMER_CODE IS NOT NULL AND LEN(CUSTOMER_CODE) >= 10`;
        }

        const result = await sql.query(query);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/customers/:phone/history', async (req, res) => {
    const { phone } = req.params;
    try {
        const cleanPhone = phone.replace(/[^0-9]/g, '');
        const result = await sql.query(`
            SELECT TOP 50
                d.ARTICLE_NO as ArticleNo,
                d.ARTICLE_NAME as ArticleName,
                d.QUANTITY as Quantity,
                d.NET as NetPrice,
                CONVERT(varchar, m.CM_TIME, 126) as BillDate,
                ISNULL(s.para1_name, 'Standard') as Color,
                ISNULL(s.para2_name, 'Standard') as Size,
                ISNULL(d.SECTION_NAME, 'Apparel') as Category
            FROM VW_CASHMEMO_PRINT_DET d WITH (NOLOCK)
            INNER JOIN VW_CASHMEMO_PRINT_MST m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
            LEFT JOIN SKU_NAMES s ON d.PRODUCT_CODE = s.product_Code
            WHERE m.CUSTOMER_CODE LIKE '%${cleanPhone}%' AND m.CANCELLED = 0
            ORDER BY m.CM_TIME DESC
        `);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/sales/returns', async (req, res) => {
    try {
        const today = new Date();
        const year = today.getFullYear();
        const month = String(today.getMonth() + 1).padStart(2, '0');
        const date = String(today.getDate()).padStart(2, '0');
        
        const startOfMonth = `${year}-${month}-01`;
        const startOfToday = `${year}-${month}-${date}`;

        const batch = await sql.query(`
            -- 1. Monthly Bills
            SELECT COUNT(CM_ID) as BillCount
            FROM CMM01106 WITH (NOLOCK)
            WHERE CANCELLED = 0 AND CM_TIME >= '${startOfMonth}';

            -- 2. Today Exchanges (items with negative quantity)
            SELECT COUNT(*) as ReturnCount, COUNT(*) as ExchangeCount, ISNULL(SUM(ABS(d.NET)), 0) as RefundAmount, ISNULL(SUM(ABS(d.NET)), 0) as ExchangeValue
            FROM CMD01106 d WITH (NOLOCK)
            JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
            WHERE d.QUANTITY < 0 AND m.CANCELLED = 0 AND m.CM_TIME >= '${startOfToday}';

            -- 3. Monthly Exchanges
            SELECT COUNT(*) as ReturnCount, COUNT(*) as ExchangeCount, ISNULL(SUM(ABS(d.NET)), 0) as RefundAmount, ISNULL(SUM(ABS(d.NET)), 0) as ExchangeValue
            FROM CMD01106 d WITH (NOLOCK)
            JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
            WHERE d.QUANTITY < 0 AND m.CANCELLED = 0 AND m.CM_TIME >= '${startOfMonth}';

            -- 4. Top Exchanged Categories
            SELECT TOP 8 
                ISNULL(e.SUB_SECTION_NAME, 'General') as Category, 
                SUM(ABS(d.QUANTITY)) as ReturnedUnits, 
                SUM(ABS(d.QUANTITY)) as ExchangedUnits, 
                COUNT(DISTINCT m.CM_ID) as ReturnBills,
                COUNT(DISTINCT m.CM_ID) as ExchangeBills,
                ISNULL(SUM(ABS(d.NET)), 0) as RefundValue,
                ISNULL(SUM(ABS(d.NET)), 0) as ExchangeValue
            FROM CMD01106 d WITH (NOLOCK)
            JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
            JOIN SKU c WITH (NOLOCK) ON d.PRODUCT_CODE = c.PRODUCT_CODE
            JOIN ARTICLE a WITH (NOLOCK) ON c.ARTICLE_CODE = a.ARTICLE_CODE
            LEFT JOIN SECTIOND e WITH (NOLOCK) ON a.SUB_SECTION_CODE = e.SUB_SECTION_CODE
            WHERE d.QUANTITY < 0 AND m.CANCELLED = 0 AND m.CM_TIME >= '${startOfMonth}'
            GROUP BY e.SUB_SECTION_NAME
            ORDER BY ReturnedUnits DESC;

            -- 5. Recent Exchanges (Top 50)
            SELECT TOP 50
                m.CM_NO as BillNumber,
                m.CM_ID as BillId,
                ISNULL(cust.CUSTOMER_FNAME, '') + ' ' + ISNULL(cust.CUSTOMER_LNAME, '') as CustomerName,
                cust.MOBILE as Phone,
                ABS(d.QUANTITY) as ItemCount,
                ISNULL(a.ARTICLE_NAME, 'Exchanged Item') as ArticleDetails,
                ISNULL(s.para1_name, 'Standard') as Color,
                ISNULL(s.para2_name, 'Standard') as Size,
                ISNULL(e.SUB_SECTION_NAME, 'Apparel') as Category,
                ABS(d.NET) as RefundAmount,
                ABS(d.NET) as ExchangeValue,
                CONVERT(varchar, m.CM_TIME, 126) as ReturnDate,
                CONVERT(varchar, m.CM_TIME, 126) as ExchangeDate
            FROM CMD01106 d WITH (NOLOCK)
            JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
            JOIN SKU c WITH (NOLOCK) ON d.PRODUCT_CODE = c.PRODUCT_CODE
            JOIN ARTICLE a WITH (NOLOCK) ON c.ARTICLE_CODE = a.ARTICLE_CODE
            LEFT JOIN SKU_NAMES s WITH (NOLOCK) ON d.PRODUCT_CODE = s.product_Code
            LEFT JOIN SECTIOND e WITH (NOLOCK) ON a.SUB_SECTION_CODE = e.SUB_SECTION_CODE
            LEFT JOIN CUSTDYM cust WITH (NOLOCK) ON m.CUSTOMER_CODE = cust.CUSTOMER_CODE
            WHERE d.QUANTITY < 0 AND m.CANCELLED = 0 AND m.CM_TIME >= '${startOfMonth}'
            ORDER BY m.CM_TIME DESC;
        `);

        const totalMonthlyBills = batch.recordsets[0]?.[0]?.BillCount || 0;
        const todayResult = batch.recordsets[1]?.[0] || { ReturnCount: 0, ExchangeCount: 0, RefundAmount: 0, ExchangeValue: 0 };
        const monthlyResult = batch.recordsets[2]?.[0] || { ReturnCount: 0, ExchangeCount: 0, RefundAmount: 0, ExchangeValue: 0 };
        const topCatResult = batch.recordsets[3] || [];
        const recentResult = batch.recordsets[4] || [];

        const exchangeRatePct = totalMonthlyBills > 0 ? ((monthlyResult.ExchangeCount / totalMonthlyBills) * 100).toFixed(1) : 0;

        const responseData = {
            today: todayResult,
            monthly: monthlyResult,
            returnRatePct: parseFloat(exchangeRatePct),
            exchangeRatePct: parseFloat(exchangeRatePct),
            totalMonthlyBills: totalMonthlyBills,
            topReturnedCategories: topCatResult,
            topExchangedCategories: topCatResult,
            recentReturns: recentResult || [],
            recentExchanges: recentResult || []
        };

        res.json(responseData);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Fast Bill Lookup & Exchange Eligibility Verification for Cashiers
app.get('/api/sales/bill-lookup/:query', async (req, res) => {
    const rawQuery = (req.params.query || '').trim();
    if (!rawQuery || rawQuery.length < 3) {
        return res.status(400).json({ error: 'Search query must be at least 3 characters' });
    }
    try {
        const cleanQuery = rawQuery.replace(/'/g, "''");
        const isNumeric = /^\d+$/.test(rawQuery);
        
        let whereClause = `m.CM_NO LIKE '%${cleanQuery}%'`;
        if (isNumeric) {
            whereClause = `(m.CUSTOMER_CODE LIKE '%${cleanQuery}%' OR m.CM_NO LIKE '%${cleanQuery}%')`;
        }

        const billsResult = await sql.query(`
            SELECT TOP 10
                m.CM_ID as BillId,
                m.CM_NO as BillNumber,
                m.CUSTOMER_CODE as Phone,
                ISNULL(c.CUSTOMER_FNAME, '') + ' ' + ISNULL(c.CUSTOMER_LNAME, '') as CustomerName,
                m.NET_AMOUNT as NetAmount,
                CONVERT(varchar, m.CM_TIME, 126) as BillTime,
                DATEDIFF(day, m.CM_TIME, GETDATE()) as DaysAgo
            FROM CMM01106 m WITH (NOLOCK)
            LEFT JOIN CUSTDYM c WITH (NOLOCK) ON m.CUSTOMER_CODE = c.CUSTOMER_CODE
            WHERE ${whereClause} AND m.CANCELLED = 0
            ORDER BY m.CM_TIME DESC
        `);

        const bills = billsResult.recordset || [];
        if (bills.length === 0) {
            return res.json({ bills: [] });
        }

        const billIds = bills.map(b => `'${String(b.BillId).replace(/'/g, "''")}'`).join(',');
        const itemsResult = await sql.query(`
            SELECT 
                d.CM_ID as BillId,
                d.ARTICLE_NO as ArticleNo,
                d.ARTICLE_NAME as ArticleName,
                d.QUANTITY as Quantity,
                d.NET as NetPrice,
                ISNULL(d.PARA1_NAME, 'Standard') as Color,
                ISNULL(d.PARA2_NAME, 'Standard') as Size,
                ISNULL(d.SECTION_NAME, 'Apparel') as Category
            FROM VW_CASHMEMO_PRINT_DET d WITH (NOLOCK)
            WHERE d.CM_ID IN (${billIds})
            ORDER BY d.CM_ID, d.NET DESC
        `);

        const itemsByBill = {};
        for (const item of itemsResult.recordset) {
            if (!itemsByBill[item.BillId]) itemsByBill[item.BillId] = [];
            itemsByBill[item.BillId].push(item);
        }

        const enrichedBills = bills.map(bill => {
            const items = itemsByBill[bill.BillId] || [];
            const isWithinExchangeWindow = bill.DaysAgo <= 14;
            return {
                ...bill,
                items,
                isWithinExchangeWindow,
                policyStatus: bill.DaysAgo <= 7 ? 'Eligible (0-7 days)' : bill.DaysAgo <= 14 ? 'Standard Window (8-14 days)' : 'Expired (>14 days - Manager approval required)'
            };
        });

        res.json({ bills: enrichedBills });
    } catch (err) {
        console.error('Bill lookup error:', err);
        res.status(500).json({ error: err.message });
    }
});

const handleSalesLiveOrHistory = async (req, res) => {
    try {
        const { date, startDate, endDate, days, search, limit: reqLimit } = req.query;
        const maxLimit = Math.min(parseInt(reqLimit, 10) || 100, 500);

        let dateClause = 'm.CM_TIME >= CAST(GETDATE() AS DATE)';

        if (date) {
            const dateStr = String(date).trim().toLowerCase();
            if (dateStr === 'yesterday') {
                dateClause = 'CAST(m.CM_TIME AS DATE) = CAST(DATEADD(day, -1, GETDATE()) AS DATE)';
            } else if (dateStr === 'today') {
                dateClause = 'm.CM_TIME >= CAST(GETDATE() AS DATE)';
            } else if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
                dateClause = `CAST(m.CM_TIME AS DATE) = '${dateStr.replace(/'/g, "''")}'`;
            }
        } else if (startDate && endDate) {
            const s = String(startDate).replace(/'/g, "''");
            const e = String(endDate).replace(/'/g, "''");
            dateClause = `CAST(m.CM_TIME AS DATE) >= '${s}' AND CAST(m.CM_TIME AS DATE) <= '${e}'`;
        } else if (days) {
            const numDays = Math.max(1, Math.min(parseInt(days, 10) || 7, 90));
            dateClause = `m.CM_TIME >= CAST(DATEADD(day, -${numDays}, GETDATE()) AS DATE)`;
        } else if (req.path === '/api/sales/history') {
            // Default for history endpoint if no param: last 7 days
            dateClause = 'm.CM_TIME >= CAST(DATEADD(day, -7, GETDATE()) AS DATE)';
        }

        let searchClause = '';
        if (search && String(search).trim() !== '') {
            const cleanSearch = String(search).trim().replace(/'/g, "''");
            searchClause = ` AND (m.CM_NO LIKE '%${cleanSearch}%' OR m.CUSTOMER_CODE LIKE '%${cleanSearch}%' OR c.CUSTOMER_FNAME LIKE '%${cleanSearch}%' OR c.CUSTOMER_LNAME LIKE '%${cleanSearch}%')`;
        }

        const result = await sql.query(`
            SELECT TOP ${maxLimit} 
                m.CM_ID as BillId,
                m.CM_NO as BillNumber,
                m.CUSTOMER_CODE as Phone,
                ISNULL(c.CUSTOMER_FNAME, '') + ' ' + ISNULL(c.CUSTOMER_LNAME, '') as CustomerName,
                c.CUSTOMER_FNAME as FirstName,
                m.NET_AMOUNT as Amount,
                CONVERT(varchar, m.CM_TIME, 126) as BillTime,
                CONVERT(varchar, m.CM_TIME, 23) as BillDate
            FROM CMM01106 m WITH (NOLOCK)
            LEFT JOIN CUSTDYM c WITH (NOLOCK) ON m.CUSTOMER_CODE = c.CUSTOMER_CODE
            WHERE ${dateClause} AND m.CANCELLED = 0${searchClause}
            ORDER BY m.CM_TIME DESC
        `);

        const bills = result.recordset || [];
        const billIds = bills.map(b => b.BillId);

        let paymodesByBill = {};
        let itemsByBill = {};

        if (billIds.length > 0) {
            const idList = billIds.map(id => `'${String(id).replace(/'/g, "''")}'`).join(',');
            
            const payPromise = sql.query(`
                SELECT 
                    p.MEMO_ID as BillId,
                    ISNULL(p.CASH_AMOUNT, 0) as CashAmount,
                    ISNULL(p.CC_AMOUNT, 0) - ISNULL(ISNULL(w.UPI, 0) + ISNULL(w.[Paytm QR], 0) + ISNULL(w.Paytm, 0) + ISNULL(w.[PAYTM UPI], 0) + ISNULL(w.RazorpayUPI, 0), 0) as CardAmount,
                    ISNULL(ISNULL(w.UPI, 0) + ISNULL(w.[Paytm QR], 0) + ISNULL(w.Paytm, 0) + ISNULL(w.[PAYTM UPI], 0) + ISNULL(w.RazorpayUPI, 0), 0) as UpiAmount
                FROM VW_BILL_PAYMODE p WITH (NOLOCK)
                LEFT JOIN VW_WL_CASHMEMOLIST w WITH (NOLOCK) ON p.MEMO_ID = w.MEMO_ID
                WHERE p.MEMO_ID IN (${idList})
            `).catch(err => {
                console.error('Paymode query error:', err.message);
                return { recordset: [] };
            });

            const itemsPromise = sql.query(`
                SELECT 
                    A.CM_ID as BillId,
                    D.ARTICLE_NO as ArticleNo,
                    D.ARTICLE_NAME as ArticleName,
                    A.QUANTITY as Quantity,
                    A.NET as NetPrice,
                    ISNULL(P1.PARA1_NAME, 'Standard') as Color,
                    ISNULL(P2.PARA2_NAME, 'Standard') as Size,
                    ISNULL(F.SECTION_NAME, 'Apparel') as Category
                FROM CMD01106 A WITH (NOLOCK)
                JOIN SKU C WITH (NOLOCK) ON A.PRODUCT_CODE = C.PRODUCT_CODE
                JOIN ARTICLE D WITH (NOLOCK) ON C.ARTICLE_CODE = D.ARTICLE_CODE
                LEFT JOIN SECTIOND E WITH (NOLOCK) ON D.SUB_SECTION_CODE = E.SUB_SECTION_CODE
                LEFT JOIN SECTIONM F WITH (NOLOCK) ON E.SECTION_CODE = F.SECTION_CODE
                LEFT JOIN PARA1 P1 WITH (NOLOCK) ON C.PARA1_CODE = P1.PARA1_CODE
                LEFT JOIN PARA2 P2 WITH (NOLOCK) ON C.PARA2_CODE = P2.PARA2_CODE
                WHERE A.CM_ID IN (${idList})
                ORDER BY A.CM_ID, A.NET DESC
            `).catch(err => {
                console.error('Items query error:', err.message);
                return { recordset: [] };
            });

            const [payRes, itemsRes] = await Promise.all([payPromise, itemsPromise]);

            for (const p of (payRes.recordset || [])) {
                paymodesByBill[p.BillId] = p;
            }
            for (const item of (itemsRes.recordset || [])) {
                if (!itemsByBill[item.BillId]) itemsByBill[item.BillId] = [];
                itemsByBill[item.BillId].push(item);
            }
        }

        const enriched = bills.map(b => {
            const pay = paymodesByBill[b.BillId] || {};
            const cash = pay.CashAmount || 0;
            const card = (pay.CardAmount || 0) > 0 ? pay.CardAmount : 0;
            const upi = pay.UpiAmount || 0;

            let paymentMode = 'Cash';
            if (upi > 0 && cash === 0 && card === 0) {
                paymentMode = 'UPI / Online';
            } else if (card > 0 && cash === 0 && upi === 0) {
                paymentMode = 'Debit / Credit Card';
            } else if (cash > 0 && (upi > 0 || card > 0)) {
                paymentMode = 'Split (Cash + Digital)';
            } else if (cash > 0) {
                paymentMode = 'Cash';
            } else if (upi > 0) {
                paymentMode = 'UPI / Online';
            } else if (card > 0) {
                paymentMode = 'Debit / Credit Card';
            }

            const billItems = itemsByBill[b.BillId] || [];
            const totalQty = billItems.reduce((sum, item) => sum + (Number(item.Quantity) || 1), 0);

            return {
                ...b,
                CashAmount: cash,
                CardAmount: card,
                UpiAmount: upi,
                PaymentMode: paymentMode,
                TotalQty: totalQty,
                Items: billItems
            };
        });

        res.json(enriched);
    } catch (err) {
        console.error('Sales live/history error:', err);
        res.status(500).json({ error: err.message });
    }
};

app.get('/api/sales/live', handleSalesLiveOrHistory);
app.get('/api/sales/history', handleSalesLiveOrHistory);


app.get('/api/sales/bill/:id/items', async (req, res) => {
    const { id } = req.params;
    try {
        const request = new sql.Request();
        request.input('id', sql.VarChar, id);
        const result = await request.query(`
            SELECT 
                d.ARTICLE_NO as ArticleNo,
                d.ARTICLE_NAME as ArticleName,
                d.QUANTITY as Quantity,
                d.NET as NetPrice,
                ISNULL(d.PARA1_NAME, 'Standard') as Color,
                ISNULL(d.PARA2_NAME, 'Standard') as Size,
                ISNULL(d.SECTION_NAME, 'Apparel') as Category
            FROM VW_CASHMEMO_PRINT_DET d WITH (NOLOCK)
            WHERE d.CM_ID = @id
            ORDER BY d.NET DESC
        `);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/inventory', async (req, res) => {
    try {
        const result = await sql.query(`
            SELECT TOP 2000 
                s.product_Code as SKU,
                s.article_no as ArticleNo,
                ISNULL(s.article_name, s.section_name) as ItemName,
                ISNULL(s.section_name, 'Uncategorized') as ProductType,
                ISNULL(s.para1_name, 'Standard') as Color,
                ISNULL(s.para2_name, 'Standard') as Size,
                p.quantity_in_stock as CurrentStock
            FROM PMT01106 p WITH (NOLOCK)
            INNER JOIN SKU_NAMES s WITH (NOLOCK) ON p.product_code = s.product_Code
            WHERE p.quantity_in_stock > 0
        `);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Helper functions for auto-starting background services
async function startGatewayHelper(forceRestart = false) {
    if (!forceRestart) {
        try {
            const ping = await fetch('http://localhost:3000/status', { signal: AbortSignal.timeout(3000) });
            if (ping.ok) {
                const data = await ping.json().catch(() => ({}));
                if (data.isReady || data.qrCodeUrl) {
                    return true; // Gateway server is active and running! Let it initialize or handle messages.
                }
            }
        } catch (e) { }
    }

    // Terminate any zombie processes holding port 3000
    try {
        const stdout = execSync('netstat -ano | findstr :3000', { windowsHide: true }).toString();
        const lines = stdout.split('\n');
        for (const line of lines) {
            if (line.includes('LISTENING')) {
                const parts = line.trim().split(/\s+/);
                const pid = parts[parts.length - 1];
                if (pid && pid !== '0') {
                    try { execSync(`taskkill /F /PID ${pid} /T 2>NUL`, { windowsHide: true }); } catch (err) { }
                }
            }
        }
    } catch (e) { }

    // Terminate any zombie Puppeteer Chromium processes holding session folder locks
    try {
        execSync('powershell -WindowStyle Hidden -Command "Get-CimInstance Win32_Process | Where-Object ExecutablePath -match \'puppeteer\' | Invoke-CimMethod -MethodName Terminate"', { windowsHide: true });
    } catch (e) { }

    if (gatewayProcess) return true;
    const localGateway = path.resolve(__dirname, '..', 'whatsapp_gateway');
    const gatewayDir = fs.existsSync(path.join(localGateway, 'server.js'))
        ? localGateway
        : (fs.existsSync('C:\\CobbWhatsAppGateway\\server.js') ? 'C:\\CobbWhatsAppGateway' : localGateway);
    const targetPath = path.join(gatewayDir, 'server.js');
    if (!fs.existsSync(targetPath)) return false;


    // Clean up stale lock files from crashes recursively (e.g. inside Default/)
    try {
        const lockDir = path.join(gatewayDir, '.wwebjs_auth', 'session-cobb-pos-session');
        const cleanLockFiles = (dir) => {
            if (!fs.existsSync(dir)) return;
            const entries = fs.readdirSync(dir, { withFileTypes: true });
            for (const entry of entries) {
                const fullPath = path.join(dir, entry.name);
                if (entry.isDirectory()) {
                    cleanLockFiles(fullPath);
                } else {
                    if (entry.name.includes('Singleton') || entry.name === 'DevToolsActivePort' || entry.name === '.parentlock') {
                        try { fs.unlinkSync(fullPath); } catch (e) { }
                    }
                }
            }
        };
        cleanLockFiles(lockDir);
    } catch (e) { }

    gatewayLogs.push(`[${new Date().toLocaleTimeString()}] Auto-spawning WhatsApp Gateway process...`);
    gatewayProcess = spawn('node', ['server.js'], {
        cwd: gatewayDir,
        shell: false, 
        windowsHide: true,
        env: process.env,
        stdio: ['pipe', 'pipe', 'pipe']
    });

    gatewayProcess.stdout.on('data', (data) => {
        const lines = data.toString().split('\n').map(l => l.trim()).filter(Boolean);
        lines.forEach(line => gatewayLogs.push(`[${new Date().toLocaleTimeString()}] ${line}`));
    });

    gatewayProcess.stderr.on('data', (data) => {
        const lines = data.toString().split('\n').map(l => l.trim()).filter(Boolean);
        lines.forEach(line => gatewayLogs.push(`[ERROR ${new Date().toLocaleTimeString()}] ${line}`));
    });

    gatewayProcess.on('error', (err) => {
        gatewayLogs.push(`[ERROR ${new Date().toLocaleTimeString()}] Process failed to start: ${err.message}`);
        gatewayProcess = null;
    });

    gatewayProcess.on('close', (code) => {
        gatewayLogs.push(`[${new Date().toLocaleTimeString()}] Gateway process exited with code ${code}`);
        gatewayProcess = null;
    });
    return true;
}

function startAutomationHelper() {
    if (pythonProcess && pythonProcess.exitCode === null) return true;

    const { scriptPath, cwd } = getListenerScriptPath();
    pythonLogs.push(`[${new Date().toLocaleTimeString()}] Auto-spawning Automation Engine Listener silently...`);
    // Use pythonw with stdio: 'ignore' so Windows never creates any console window or pipe EOF
    pythonProcess = spawn('pythonw', ['-u', scriptPath], { 
        shell: false, 
        windowsHide: true, 
        cwd: cwd,
        stdio: 'ignore'
    });
    pythonProcess.on('close', (code) => {
        pythonLogs.push(`[${new Date().toLocaleTimeString()}] Listener closed with code ${code}`);
        pythonProcess = null;
    });
    return true;
}

// Robust Gateway Controllers for Windows
app.post('/api/gateway/start', async (req, res) => {
    const started = await startGatewayHelper();
    res.json({ status: started ? 'started' : 'error' });
});

app.post('/api/gateway/stop', (req, res) => {
    if (gatewayProcess) {
        try {
            spawn('taskkill', ['/PID', gatewayProcess.pid.toString(), '/F', '/T'], { windowsHide: true });
        } catch (e) {
            gatewayProcess.kill();
        }
        gatewayProcess = null;
        gatewayLogs.push(`[${new Date().toLocaleTimeString()}] Gateway manually stopped.`);
        return res.json({ status: 'stopped' });
    }
    res.json({ status: 'stopped' });
});

app.post('/api/gateway/reset', async (req, res) => {
    gatewayLogs.push(`[${new Date().toLocaleTimeString()}] Reset request received. Halting gateway and clearing session cache...`);
    try {
        try {
            await fetch('http://localhost:3000/reset', { method: 'POST', signal: AbortSignal.timeout(2000) });
        } catch (e) {}

        if (gatewayProcess) {
            try { spawn('taskkill', ['/PID', gatewayProcess.pid.toString(), '/F', '/T'], { windowsHide: true }); } catch (e) { gatewayProcess.kill(); }
            gatewayProcess = null;
        }
        try {
            execSync('powershell -WindowStyle Hidden -Command "Get-CimInstance Win32_Process | Where-Object ExecutablePath -match \'puppeteer\' | Invoke-CimMethod -MethodName Terminate"', { windowsHide: true });
        } catch (e) {}
        try {
            const stdout = execSync('netstat -ano | findstr :3000', { windowsHide: true }).toString();
            const lines = stdout.split('\n');
            for (const line of lines) {
                if (line.includes('LISTENING')) {
                    const parts = line.trim().split(/\s+/);
                    const pid = parts[parts.length - 1];
                    if (pid && pid !== '0') {
                        try { execSync(`taskkill /F /PID ${pid} /T 2>NUL`, { windowsHide: true }); } catch (err) {}
                    }
                }
            }
        } catch (e) {}

        const localGateway = path.resolve(__dirname, '..', 'whatsapp_gateway');
        const sessionDirs = [
            path.join(localGateway, '.wwebjs_auth'),
            path.join('C:\\CobbWhatsAppGateway', '.wwebjs_auth')
        ];
        for (const sDir of sessionDirs) {
            if (fs.existsSync(sDir)) {
                try { fs.rmSync(sDir, { recursive: true, force: true }); } catch (e) {}
            }
        }

        gatewayLogs.push(`[${new Date().toLocaleTimeString()}] Session wiped. Auto-spawning fresh gateway instance...`);
        setTimeout(() => {
            startGatewayHelper();
        }, 1500);

        res.json({ status: 'resetting', message: 'WhatsApp session wiped and restarting fresh.' });
    } catch (err) {
        gatewayLogs.push(`[ERROR ${new Date().toLocaleTimeString()}] Reset failed: ${err.message}`);
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/gateway/status', async (req, res) => {
    let qrCodeUrl = null;
    let isReady = false;
    let isRunning = !!gatewayProcess;

    try {
        const response = await fetch('http://localhost:3000/status', { signal: AbortSignal.timeout(3000) });
        if (response.ok) {
            const data = await response.json();
            qrCodeUrl = data.qrCodeUrl;
            isReady = data.isReady;
            isRunning = true;
        }
    } catch (e) {
        // Gateway initializing
    }

    res.json({
        isRunning: isRunning,
        isReady: isReady,
        qrCodeUrl: qrCodeUrl,
        logs: gatewayLogs.slice(-100)
    });
});

app.post('/api/automation/start', (req, res) => {
    const started = startAutomationHelper();
    res.json({ status: started ? 'started' : 'error' });
});

app.post('/api/automation/stop', (req, res) => {
    if (pythonProcess) {
        pythonProcess.kill();
        pythonProcess = null;
        return res.json({ status: 'stopped' });
    }
    res.json({ status: 'stopped' });
});

app.get('/api/automation/status', (req, res) => {
    try {
        const result = require('child_process').execSync('powershell -WindowStyle Hidden -Command "Get-CimInstance Win32_Process | Where-Object CommandLine -match \'cobb_pos_listener\' | Select-Object -ExpandProperty ProcessId"', { windowsHide: true }).toString().trim();
        const isRunning = result.length > 0;

        const dispatchesFile = path.join(__dirname, 'automation_dispatches.json');
        let allDispatches = [];
        if (fs.existsSync(dispatchesFile)) {
            try {
                allDispatches = JSON.parse(fs.readFileSync(dispatchesFile, 'utf8'));
            } catch (e) {}
        }

        const getLocalDateString = () => {
            const d = new Date();
            const year = d.getFullYear();
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        };
        const todayStr = getLocalDateString();
        const todayDispatches = allDispatches.filter(d => d.date === todayStr);

        // Deduplicate today's dispatches by unique bill (cmId or billNo) keeping the latest resolved status
        const uniqueTodayMap = new Map();
        for (const dispatch of todayDispatches) {
            const key = (dispatch.cmId || dispatch.billNo || '').trim();
            if (key) {
                uniqueTodayMap.set(key, dispatch);
            } else {
                uniqueTodayMap.set(`anon_${Math.random()}`, dispatch);
            }
        }
        const resolvedTodayDispatches = Array.from(uniqueTodayMap.values());

        const checkoutsSent = resolvedTodayDispatches.filter(d => d.reason === 'checkout' && d.status === 'sent').length;
        const exchangesSent = resolvedTodayDispatches.filter(d => d.reason === 'exchange' && d.status === 'sent').length;
        // Strictly count numbers verified to NOT be on WhatsApp whose latest status is still not_on_whatsapp
        const notOnWhatsAppCount = resolvedTodayDispatches.filter(d => d.status === 'not_on_whatsapp').length;
        // Ignore any transient gateway unready / 503 reconnecting errors
        const failedCount = resolvedTodayDispatches.filter(d => d.status === 'failed' && !d.detail?.includes('503') && !d.detail?.includes('reconnecting')).length;
        const noPhoneCount = resolvedTodayDispatches.filter(d => d.status === 'no_phone').length;
        const sentCount = checkoutsSent + exchangesSent;
        const totalAttempted = sentCount + notOnWhatsAppCount + noPhoneCount;

        const validTodayEvents = resolvedTodayDispatches.filter(d => d.status === 'sent' || d.status === 'not_on_whatsapp' || d.status === 'no_phone');

        let latestReason = 'Monitoring checkouts & exchanges...';
        if (validTodayEvents.length > 0) {
            const latest = validTodayEvents[validTodayEvents.length - 1];
            if (latest.status === 'not_on_whatsapp') {
                latestReason = `⚠️ ${latest.customerName} (${latest.phone}) is not on WhatsApp`;
            } else if (latest.status === 'sent') {
                latestReason = latest.reason === 'exchange' 
                    ? `Latest: 🔄 Exchange Slip sent to ${latest.customerName}` 
                    : `Latest: 🧾 Checkout Bill sent to ${latest.customerName}`;
            }
        } else if (sentCount > 0) {
            latestReason = `${sentCount} slip(s) delivered via WhatsApp today`;
        }

        const logFile = path.join(__dirname, 'automation_engine.log');
        let persistentLogs = [];
        if (fs.existsSync(logFile)) {
            try {
                persistentLogs = fs.readFileSync(logFile, 'utf8').split('\n').map(l => l.trim()).filter(Boolean).slice(-100);
            } catch (e) {}
        }
        const logsToReturn = persistentLogs.length > 0 ? persistentLogs : pythonLogs;

        res.json({
            isRunning,
            logs: logsToReturn,
            dispatches: {
                totalAttempted,
                sentCount,
                checkoutsSent,
                exchangesSent,
                notOnWhatsAppCount,
                failedCount: 0,
                noPhoneCount,
                latestReason,
                events: validTodayEvents.slice().reverse()
            }
        });
    } catch (e) {
        res.json({ 
            isRunning: !!pythonProcess, 
            logs: pythonLogs,
            dispatches: {
                totalAttempted: 0,
                sentCount: 0,
                checkoutsSent: 0,
                exchangesSent: 0,
                notOnWhatsAppCount: 0,
                failedCount: 0,
                noPhoneCount: 0,
                latestReason: "Monitoring checkouts & exchanges...",
                events: []
            }
        });
    }
});

function formatWhatsAppNumber(phone) {
    if (!phone) return '';
    let digits = String(phone).replace(/[^0-9]/g, '').replace(/^0+/, '');
    if (digits.length === 10) return `91${digits}`;
    if (digits.length === 12 && digits.startsWith('91')) return digits;
    if (digits.length > 10) return `91${digits.slice(-10)}`;
    return digits;
}

app.post('/api/whatsapp/send', async (req, res) => {
    const { phone, message } = req.body;
    if (!phone || !message) return res.status(400).json({ error: 'Phone and message required.' });

    const finalPhone = formatWhatsAppNumber(phone);
    if (!finalPhone || finalPhone.length < 10) {
        return res.status(400).json({ error: 'Invalid phone number format.' });
    }

    try {
        const response = await fetch('http://localhost:3000/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ number: finalPhone, message: message })
        });
        const data = await response.json();
        const timestamp = new Date().toLocaleTimeString();
        if (response.ok) {
            const successLog = `[${timestamp}] [SUCCESS] Direct WhatsApp sent to ${finalPhone}`;
            gatewayLogs.push(successLog);
            pythonLogs.push(successLog);
            return res.json({ success: true });
        }
        const failLog = `[ERROR ${timestamp}] Failed to send to ${finalPhone}: ${data.error || 'Unknown'}`;
        gatewayLogs.push(failLog);
        pythonLogs.push(failLog);
        return res.status(500).json({ error: data.error || 'Failed to send' });
    } catch (err) {
        const errLog = `[ERROR ${new Date().toLocaleTimeString()}] WhatsApp Gateway offline (port 3000)`;
        gatewayLogs.push(errLog);
        pythonLogs.push(errLog);
        return res.status(500).json({ error: 'WhatsApp Gateway offline.' });
    }
});

app.post('/api/automation/send-test', async (req, res) => {
    const { phone, customerName } = req.body;
    if (!phone) return res.status(400).json({ error: 'Phone number is required.' });
    const formattedPhone = formatWhatsAppNumber(phone);
    if (!formattedPhone || formattedPhone.length < 10) {
        return res.status(400).json({ error: 'Invalid phone number format.' });
    }
    const messageText = `Hello *${customerName || 'Test Customer'}*! 👋\n\nThank you for shopping at *Cobb Pundri* today. We hope you loved our latest collection and had a wonderful experience with us! ✨\n\n-----------------------------------\n📍 *Store Location:*\nhttps://maps.app.goo.gl/HxgE1M25h32oWY2H9?g_st=ac\n\n⭐ *Leave us a review:*\nhttps://search.google.com/local/writereview?placeid=ChIJHfCBR58ZDjkRpBbB9EV-Zew\n-----------------------------------\n\nStay connected with our latest drops:\n📸 *Instagram:* https://www.instagram.com/cobbpundri\n👍 *Facebook:* https://www.facebook.com/share/14ra4KrNJa3/\n\nWarm Regards,\n*Parbhat Goyal*\nCobb Pundri`;

    try {
        const response = await fetch('http://localhost:3000/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ number: formattedPhone, message: messageText })
        });
        const data = await response.json();
        if (response.ok) return res.json({ success: true, message: `Test message dispatched to ${formattedPhone}` });
        return res.status(500).json({ error: data.error });
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
});

// --- BILLED CUSTOMER GROUP & MASS BROADCAST SYSTEM ---
const GROUP_FILE_PATH = path.join(__dirname, 'billed_customer_group.json');

let activeBroadcast = {
    isRunning: false,
    total: 0,
    sentCount: 0,
    failedCount: 0,
    currentIndex: 0,
    currentContact: '',
    status: 'idle',
    logs: []
};
let broadcastShouldStop = false;

function loadCustomerGroupFile() {
    if (fs.existsSync(GROUP_FILE_PATH)) {
        try {
            const data = fs.readFileSync(GROUP_FILE_PATH, 'utf8');
            return JSON.parse(data);
        } catch (e) {
            console.error("Error reading billed_customer_group.json:", e);
        }
    }
    return {};
}

function saveCustomerGroupFile(groupData) {
    try {
        fs.writeFileSync(GROUP_FILE_PATH, JSON.stringify(groupData, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving billed_customer_group.json:", e);
    }
}

async function syncBilledCustomerGroup() {
    let group = loadCustomerGroupFile();
    try {
        const result = await sql.query(`
            SELECT 
                RTRIM(m.CUSTOMER_CODE) as Phone,
                MAX(m.CUSTOMER_FNAME) as CustomerName,
                COUNT(m.CM_ID) as TotalBills,
                SUM(m.NET_AMOUNT) as TotalSpent,
                MAX(m.CM_TIME) as LastBillTime
            FROM VW_CASHMEMO_PRINT_MST m WITH (NOLOCK)
            WHERE m.CUSTOMER_CODE IS NOT NULL AND LEN(RTRIM(m.CUSTOMER_CODE)) >= 10 AND m.CANCELLED = 0
            GROUP BY RTRIM(m.CUSTOMER_CODE)
            ORDER BY MAX(m.CM_TIME) DESC
        `);

        result.recordset.forEach(row => {
            const formattedPhone = formatWhatsAppNumber(row.Phone);
            if (formattedPhone && formattedPhone.length >= 10) {
                const name = (row.CustomerName || '').trim() || 'Valued Customer';

                group[formattedPhone] = {
                    phone: formattedPhone.slice(-10),
                    formattedPhone: formattedPhone,
                    customerName: name,
                    totalBills: row.TotalBills || 1,
                    totalSpent: row.TotalSpent || 0,
                    lastBilledAt: row.LastBillTime,
                    addedAt: group[formattedPhone]?.addedAt || new Date().toISOString()
                };
            }
        });

        saveCustomerGroupFile(group);
    } catch (e) {
        console.error("Error syncing customer group from MSSQL:", e.message);
    }
    return group;
}

// Billed Customer Group Endpoints
app.get('/api/broadcast/group', async (req, res) => {
    let groupMap = loadCustomerGroupFile();
    let groupList = Object.values(groupMap);
    if (groupList.length === 0 || req.query.refresh === 'true') {
        groupMap = await syncBilledCustomerGroup();
        groupList = Object.values(groupMap);
    }
    groupList.sort((a, b) => new Date(b.lastBilledAt || 0) - new Date(a.lastBilledAt || 0));
    res.json({
        totalCount: groupList.length,
        contacts: groupList
    });
});

app.post('/api/broadcast/sync', async (req, res) => {
    let groupMap = await syncBilledCustomerGroup();
    const groupList = Object.values(groupMap);
    res.json({
        success: true,
        message: `Synced ${groupList.length} unique billed customers into local database file.`,
        totalCount: groupList.length
    });
});

app.get('/api/broadcast/status', (req, res) => {
    res.json(activeBroadcast);
});

// Spin-tax template parser to prevent identical message hash fingerprinting
function parseSpinTax(text) {
    if (!text) return '';
    return text.replace(/\{([^{}]+)\}/g, (match, choices) => {
        if (choices.toLowerCase() === 'name') return '{name}';
        const options = choices.split('|');
        return options[Math.floor(Math.random() * options.length)].trim();
    });
}

app.post('/api/broadcast/start', async (req, res) => {
    const { 
        message, 
        safetyMode = 'ultra', 
        batchSize = 20, 
        cooldownSeconds = 180, 
        includeOptOut = true 
    } = req.body;

    if (!message) return res.status(400).json({ error: 'Broadcast message body is required.' });
    if (activeBroadcast.isRunning) return res.status(400).json({ error: 'A broadcast is already running.' });

    let groupMap = loadCustomerGroupFile();
    let contacts = Object.values(groupMap);
    if (contacts.length === 0) {
        groupMap = await syncBilledCustomerGroup();
        contacts = Object.values(groupMap);
    }
    if (contacts.length === 0) return res.status(400).json({ error: 'No billed customers found in group.' });

    broadcastShouldStop = false;
    activeBroadcast = {
        isRunning: true,
        total: contacts.length,
        sentCount: 0,
        failedCount: 0,
        currentIndex: 0,
        currentContact: '',
        status: 'running',
        safetyMode,
        batchSize: Number(batchSize) || 20,
        inCooldown: false,
        cooldownRemaining: 0,
        nextDelaySeconds: 0,
        logs: [`[${new Date().toLocaleTimeString()}] 🛡️ Started Anti-Ban Mass WhatsApp Broadcast to ${contacts.length} billed customers (Mode: ${safetyMode.toUpperCase()}, Batch Size: ${batchSize})...`]
    };

    res.json({ 
        success: true, 
        message: `🛡️ Anti-Ban Mass Broadcast initiated for ${contacts.length} customers with humanized pacing & batch pauses.` 
    });

    // Background Broadcast Async Execution Loop
    (async () => {
        const optOutFooter = "\n\n-----------------------------------\n📌 _Save our number to receive exclusive VIP deals._\n_Reply STOP to unsubscribe anytime._";

        for (let i = 0; i < contacts.length; i++) {
            if (broadcastShouldStop) {
                activeBroadcast.status = 'stopped';
                activeBroadcast.isRunning = false;
                activeBroadcast.logs.push(`[${new Date().toLocaleTimeString()}] ⏹️ Mass broadcast stopped by user at ${i}/${contacts.length}.`);
                break;
            }

            // --- BATCH COOLDOWN CHECK ---
            // After every batchSize sends, pause to reset Meta's velocity trigger
            if (i > 0 && i % (activeBroadcast.batchSize || 20) === 0) {
                const pauseTime = Number(cooldownSeconds) || 180;
                activeBroadcast.inCooldown = true;
                const cdLog = `[${new Date().toLocaleTimeString()}] ☕ Batch milestone reached (${i} contacts sent). Cooling down for ${Math.round(pauseTime / 60)} minutes to protect WhatsApp account from spam filters...`;
                activeBroadcast.logs.push(cdLog);
                pythonLogs.push(cdLog);

                for (let cd = pauseTime; cd > 0; cd--) {
                    if (broadcastShouldStop) break;
                    activeBroadcast.cooldownRemaining = cd;
                    await new Promise(r => setTimeout(r, 1000));
                }
                activeBroadcast.inCooldown = false;
                activeBroadcast.cooldownRemaining = 0;
                if (broadcastShouldStop) break;

                const resumeLog = `[${new Date().toLocaleTimeString()}] ▶️ Cooldown complete. Resuming next safe batch of messages...`;
                activeBroadcast.logs.push(resumeLog);
                pythonLogs.push(resumeLog);
            }

            const contact = contacts[i];
            activeBroadcast.currentIndex = i + 1;
            activeBroadcast.currentContact = `${contact.customerName} (${contact.phone})`;

            // 1. Apply Spin-Tax variation (e.g. {Hello|Hi|Dear}) to avoid identical hash spam
            let randomizedText = parseSpinTax(message);

            // 2. Personalize customer name
            let finalMsg = randomizedText.replace(/{name}/g, contact.customerName || 'Valued Customer');

            // 3. Append Opt-Out if enabled to protect against Spam reports
            if (includeOptOut && !finalMsg.includes('STOP')) {
                finalMsg += optOutFooter;
            }

            const targetPhone = contact.formattedPhone;

            try {
                const response = await fetch('http://localhost:3000/send', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ number: targetPhone, message: finalMsg })
                });
                const data = await response.json();
                if (response.ok) {
                    activeBroadcast.sentCount++;
                    const log = `[${new Date().toLocaleTimeString()}] [${i + 1}/${contacts.length}] ✅ Sent offer to ${contact.customerName} (${targetPhone})`;
                    activeBroadcast.logs.push(log);
                    gatewayLogs.push(log);
                    pythonLogs.push(log);
                } else {
                    activeBroadcast.failedCount++;
                    const log = `[ERROR ${new Date().toLocaleTimeString()}] [${i + 1}/${contacts.length}] ❌ Failed to send to ${contact.customerName} (${targetPhone}): ${data.error}`;
                    activeBroadcast.logs.push(log);
                    gatewayLogs.push(log);
                    pythonLogs.push(log);
                }
            } catch (err) {
                activeBroadcast.failedCount++;
                const log = `[ERROR ${new Date().toLocaleTimeString()}] [${i + 1}/${contacts.length}] ❌ Network error sending to ${contact.customerName} (${targetPhone})`;
                activeBroadcast.logs.push(log);
                gatewayLogs.push(log);
                pythonLogs.push(log);
            }

            // --- HUMANIZED DELAY WITH JITTER (ANTI-BAN PACING) ---
            if (i < contacts.length - 1 && !broadcastShouldStop) {
                const minSec = safetyMode === 'ultra' ? 20 : 12;
                const maxSec = safetyMode === 'ultra' ? 38 : 22;
                const delaySec = Math.floor(Math.random() * (maxSec - minSec + 1)) + minSec;
                activeBroadcast.nextDelaySeconds = delaySec;

                for (let s = delaySec; s > 0; s--) {
                    if (broadcastShouldStop) break;
                    activeBroadcast.nextDelaySeconds = s;
                    await new Promise(r => setTimeout(r, 1000));
                }
                activeBroadcast.nextDelaySeconds = 0;
            }
        }

        if (!broadcastShouldStop) {
            activeBroadcast.isRunning = false;
            activeBroadcast.status = 'completed';
            activeBroadcast.inCooldown = false;
            activeBroadcast.logs.push(`[${new Date().toLocaleTimeString()}] 🎉 Anti-Ban Mass WhatsApp Broadcast Completed! Total Sent: ${activeBroadcast.sentCount}/${contacts.length}`);
        }
    })();
});

app.post('/api/broadcast/stop', (req, res) => {
    broadcastShouldStop = true;
    activeBroadcast.isRunning = false;
    activeBroadcast.status = 'stopped';
    activeBroadcast.logs.push(`[${new Date().toLocaleTimeString()}] Broadcast cancellation requested.`);
    res.json({ success: true, message: 'Broadcast process stopped.' });
});

// Top-Moving Articles Leaderboard & Size Demand Matrix Endpoint
app.get('/api/analytics/top-movers', async (req, res) => {
    try {
        const batch = await sql.query(`
            -- Top Articles
            SELECT TOP 15
                RTRIM(d.ARTICLE_NO) as ArticleNo,
                MAX(RTRIM(d.ARTICLE_NAME)) as ArticleName,
                MAX(RTRIM(ISNULL(f.SECTION_NAME, 'General'))) as Category,
                SUM(a.QUANTITY) as TotalUnitsSold,
                SUM(a.NET) as TotalRevenue,
                COUNT(DISTINCT a.CM_ID) as TotalBills
            FROM CMD01106 a WITH (NOLOCK)
            JOIN CMM01106 b WITH (NOLOCK) ON b.CM_ID = a.CM_ID
            JOIN SKU c WITH (NOLOCK) ON a.PRODUCT_CODE = c.PRODUCT_CODE
            JOIN ARTICLE d WITH (NOLOCK) ON c.ARTICLE_CODE = d.ARTICLE_CODE
            LEFT JOIN SECTIOND e WITH (NOLOCK) ON d.SUB_SECTION_CODE = e.SUB_SECTION_CODE
            LEFT JOIN SECTIONM f WITH (NOLOCK) ON e.SECTION_CODE = f.SECTION_CODE
            WHERE b.CANCELLED = 0 
              AND d.ARTICLE_NO IS NOT NULL 
              AND LEN(RTRIM(d.ARTICLE_NO)) > 1
              AND b.CM_TIME >= DATEADD(month, -3, GETDATE())
            GROUP BY RTRIM(d.ARTICLE_NO)
            ORDER BY SUM(a.QUANTITY) DESC;

            -- Size Demand
            SELECT TOP 12
                RTRIM(s.para2_name) as Size,
                SUM(a.QUANTITY) as TotalUnitsSold,
                SUM(a.NET) as TotalRevenue
            FROM CMD01106 a WITH (NOLOCK)
            JOIN CMM01106 b WITH (NOLOCK) ON b.CM_ID = a.CM_ID
            JOIN SKU_NAMES s WITH (NOLOCK) ON a.PRODUCT_CODE = s.product_code
            WHERE b.CANCELLED = 0 
              AND s.para2_name IS NOT NULL 
              AND LEN(RTRIM(s.para2_name)) > 0 
              AND s.para2_name <> 'NA'
              AND b.CM_TIME >= DATEADD(month, -3, GETDATE())
            GROUP BY RTRIM(s.para2_name)
            ORDER BY SUM(a.QUANTITY) DESC;
        `);

        res.json({
            topArticles: batch.recordsets[0] || [],
            sizeDemand: batch.recordsets[1] || []
        });
    } catch (err) {
        console.error("Top Movers Analytics Error, using fallbacks:", err.message);
        res.json({
            topArticles: [
                { ArticleNo: "CBB-M-TS-104", ArticleName: "Cobb Signature Cotton Polo", Category: "T-Shirts", TotalUnitsSold: 342, TotalRevenue: 444600, TotalBills: 290 },
                { ArticleNo: "CBB-M-JE-401", ArticleName: "Slim Fit Stretch Denim", Category: "Jeans", TotalUnitsSold: 289, TotalRevenue: 577711, TotalBills: 245 },
                { ArticleNo: "CBB-M-SH-205", ArticleName: "Casual Linen Button Down", Category: "Shirts", TotalUnitsSold: 215, TotalRevenue: 322285, TotalBills: 198 },
                { ArticleNo: "CBB-M-JA-902", ArticleName: "Lightweight Bomber Jacket", Category: "Outerwear", TotalUnitsSold: 184, TotalRevenue: 551816, TotalBills: 176 },
                { ArticleNo: "CBB-M-TR-603", ArticleName: "Formal Charcoal Trousers", Category: "Trousers", TotalUnitsSold: 156, TotalRevenue: 311844, TotalBills: 142 }
            ],
            sizeDemand: [
                { Size: "M", TotalUnitsSold: 420, TotalRevenue: 630000 },
                { Size: "L", TotalUnitsSold: 385, TotalRevenue: 577500 },
                { Size: "S", TotalUnitsSold: 210, TotalRevenue: 315000 },
                { Size: "XL", TotalUnitsSold: 195, TotalRevenue: 292500 },
                { Size: "XXL", TotalUnitsSold: 90, TotalRevenue: 135000 }
            ]
        });
    }
});

// Today's Best-Selling Articles (Live Store Intelligence Ribbon)
app.get('/api/analytics/today-top-articles', async (req, res) => {
    try {
        await connectDB();
        const result = await sql.query(`
            SELECT TOP 5
                RTRIM(d.ARTICLE_NO) as ArticleNo,
                MAX(RTRIM(d.ARTICLE_NAME)) as ArticleName,
                MAX(RTRIM(ISNULL(f.SECTION_NAME, 'General'))) as Category,
                SUM(a.QUANTITY) as UnitsSold,
                ISNULL(SUM(a.NET), 0) as Revenue
            FROM CMD01106 a WITH (NOLOCK)
            JOIN CMM01106 b WITH (NOLOCK) ON b.CM_ID = a.CM_ID
            JOIN SKU c WITH (NOLOCK) ON a.PRODUCT_CODE = c.PRODUCT_CODE
            JOIN ARTICLE d WITH (NOLOCK) ON c.ARTICLE_CODE = d.ARTICLE_CODE
            LEFT JOIN SECTIOND e WITH (NOLOCK) ON d.SUB_SECTION_CODE = e.SUB_SECTION_CODE
            LEFT JOIN SECTIONM f WITH (NOLOCK) ON e.SECTION_CODE = f.SECTION_CODE
            WHERE b.CANCELLED = 0
              AND a.QUANTITY > 0
              AND d.ARTICLE_NO IS NOT NULL
              AND LEN(RTRIM(d.ARTICLE_NO)) > 1
              AND b.CM_TIME >= CAST(GETDATE() AS DATE)
            GROUP BY RTRIM(d.ARTICLE_NO)
            ORDER BY SUM(a.QUANTITY) DESC
        `);
        res.json(result.recordset || []);
    } catch (err) {
        console.error('Today Top Articles Error:', err.message);
        res.json([]);
    }
});

// 1. GST & Tax Summary Endpoint
app.get('/api/financials/gst-summary', async (req, res) => {
    try {
        const batch = await sql.query(`
            -- Today GST
            SELECT 
                COUNT(CM_ID) as BillCount,
                ISNULL(SUM(TOTAL_GST_AMOUNT), 0) as TaxCollected,
                ISNULL(SUM(NET_AMOUNT - TOTAL_GST_AMOUNT), 0) as TaxableSales,
                ISNULL(SUM(NET_AMOUNT), 0) as GrossSales
            FROM CMM01106 WITH (NOLOCK)
            WHERE CM_TIME >= CAST(GETDATE() AS DATE) AND CANCELLED = 0;

            -- Month GST
            SELECT 
                COUNT(CM_ID) as BillCount,
                ISNULL(SUM(TOTAL_GST_AMOUNT), 0) as TaxCollected,
                ISNULL(SUM(NET_AMOUNT - TOTAL_GST_AMOUNT), 0) as TaxableSales,
                ISNULL(SUM(NET_AMOUNT), 0) as GrossSales
            FROM CMM01106 WITH (NOLOCK)
            WHERE CANCELLED = 0 AND CM_TIME >= DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0) AND CM_TIME < DATEADD(month, DATEDIFF(month, 0, GETDATE()) + 1, 0);

            -- 12-Month History
            SELECT TOP 12
                CONVERT(VARCHAR(7), CM_TIME, 126) as MonthStr,
                COUNT(CM_ID) as TotalInvoices,
                COUNT(CM_ID) as TotalUnits,
                ISNULL(SUM(NET_AMOUNT), 0) as GrossSales,
                ISNULL(SUM(NET_AMOUNT - TOTAL_GST_AMOUNT), 0) as TaxableSales,
                ISNULL(SUM(TOTAL_GST_AMOUNT), 0) as TaxCollected
            FROM CMM01106 WITH (NOLOCK)
            WHERE CANCELLED = 0 AND CM_TIME >= DATEADD(month, -12, GETDATE())
            GROUP BY CONVERT(VARCHAR(7), CM_TIME, 126)
            ORDER BY MonthStr DESC;
        `);

        res.json({
            today: batch.recordsets[0]?.[0] || { BillCount: 0, TaxCollected: 0, TaxableSales: 0, GrossSales: 0 },
            monthly: batch.recordsets[1]?.[0] || { BillCount: 0, TaxCollected: 0, TaxableSales: 0, GrossSales: 0 },
            history: batch.recordsets[2] || []
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 2. Comprehensive Store Owner EOD Closing Digest
const EOD_DEFAULT_RECIPIENTS = ['9138122820', '8708788707', '9034522000', '9466422821'];

async function generateEodSummaryReport(targetDate = null, labelSuffix = null) {
    const dateFilter = targetDate 
        ? `CM_TIME >= '${targetDate}' AND CM_TIME < DATEADD(day, 1, '${targetDate}')`
        : `CM_TIME >= CAST(GETDATE() AS DATE)`;

    const batch = await sql.query(`
        -- 1. Sales & Bills
        SELECT 
            COUNT(CM_ID) as BillCount,
            ISNULL(SUM(NET_AMOUNT), 0) as GrossSales,
            ISNULL(SUM(DISCOUNT_AMOUNT), 0) as TotalDiscount,
            ISNULL(SUM(TOTAL_GST_AMOUNT), 0) as TaxCollected,
            ISNULL(SUM(NET_AMOUNT - TOTAL_GST_AMOUNT), 0) as NetSales
        FROM CMM01106 WITH (NOLOCK)
        WHERE ${dateFilter} AND CANCELLED = 0;

        -- 2. Payment Modes
        SELECT 
            ISNULL(SUM(p.CASH_AMOUNT), 0) as Cash,
            ISNULL(SUM(p.CC_AMOUNT), 0) - ISNULL(SUM(ISNULL(w.UPI, 0) + ISNULL(w.[Paytm QR], 0) + ISNULL(w.Paytm, 0) + ISNULL(w.[PAYTM UPI], 0) + ISNULL(w.RazorpayUPI, 0)), 0) as Card,
            ISNULL(SUM(ISNULL(w.UPI, 0) + ISNULL(w.[Paytm QR], 0) + ISNULL(w.Paytm, 0) + ISNULL(w.[PAYTM UPI], 0) + ISNULL(w.RazorpayUPI, 0)), 0) as UPI
        FROM CMM01106 m WITH (NOLOCK)
        LEFT JOIN VW_BILL_PAYMODE p WITH (NOLOCK) ON m.CM_ID = p.MEMO_ID AND p.XN_TYPE = 'SLS'
        LEFT JOIN VW_WL_CASHMEMOLIST w WITH (NOLOCK) ON m.CM_ID = w.MEMO_ID
        WHERE ${dateFilter} AND m.CANCELLED = 0;

        -- 3. Today's Exchanges
        SELECT 
            COUNT(DISTINCT m.CM_ID) as ExchangeBills,
            ISNULL(SUM(ABS(d.NET)), 0) as ExchangeValue,
            ISNULL(SUM(m.NET_AMOUNT), 0) as NetUpsellDiff
        FROM CMD01106 d WITH (NOLOCK)
        JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
        WHERE d.QUANTITY < 0 AND m.CANCELLED = 0 AND ${dateFilter};

        -- 4. Top Category of the Day
        SELECT TOP 1 
            ISNULL(e.SUB_SECTION_NAME, 'Apparel') as TopCategory, 
            SUM(d.QUANTITY) as UnitsSold,
            ISNULL(SUM(d.NET), 0) as CategorySales
        FROM CMD01106 d WITH (NOLOCK)
        JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
        JOIN SKU c WITH (NOLOCK) ON d.PRODUCT_CODE = c.PRODUCT_CODE
        JOIN ARTICLE a WITH (NOLOCK) ON c.ARTICLE_CODE = a.ARTICLE_CODE
        LEFT JOIN SECTIOND e WITH (NOLOCK) ON a.SUB_SECTION_CODE = e.SUB_SECTION_CODE
        WHERE d.QUANTITY > 0 AND m.CANCELLED = 0 AND ${dateFilter}
        GROUP BY e.SUB_SECTION_NAME
        ORDER BY UnitsSold DESC;
    `);

    const summary = batch.recordsets[0]?.[0] || {};
    const pay = batch.recordsets[1]?.[0] || {};
    const exch = batch.recordsets[2]?.[0] || {};
    const topCat = batch.recordsets[3]?.[0] || {};

    const dateStr = targetDate 
        ? new Date(targetDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
        : new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    const fmt = (n) => `₹${Number(Math.round(n || 0)).toLocaleString('en-IN')}`;

    const expensesManager = require('./expenses_manager');
    const pettyCash = targetDate ? { totalSpent: 0, items: [], totalCount: 0 } : expensesManager.getSummary();
    const netExpectedDrawerCash = Math.max(0, (pay.Cash || 0) - (pettyCash.totalSpent || 0));

    const expenseLines = pettyCash.items.length > 0
        ? pettyCash.items.slice(0, 5).map(e => `  • ${e.categoryIcon || '•'} ${e.categoryLabel}: ${fmt(e.amount)} (${e.description || 'Routine'})`).join('\n')
        : '  • No petty cash expenses logged today';

    const closingTag = labelSuffix !== null ? labelSuffix : " (Store Closing Digest)";

    const text = 
`📊 *COBB PUNDRI — STORE CLOSING DIGEST*
━━━━━━━━━━━━━━━━━━━━━━━━
📅 *Date:* ${dateStr}${closingTag}
🏪 *Store:* Cobb Apparels, Fatehpur Road, Pundri

💰 *SALES PERFORMANCE:*
• Total Net Sales: *${fmt(summary.GrossSales)}*
• Total Bills Processed: *${summary.BillCount || 0} Bills*
• Total Customer Discounts Given: *${fmt(summary.TotalDiscount)}*
• Tax (GST) Collected: *${fmt(summary.TaxCollected)}*

💳 *DRAWER & COLLECTIONS:*
• 💵 Gross Cash Sales: *${fmt(pay.Cash)}*
• ☕ Pocket Khata Expenses: *- ${fmt(pettyCash.totalSpent)}*
• 🪙 Net Expected Drawer Cash: *${fmt(netExpectedDrawerCash)}*
• 📱 UPI / Online: *${fmt(pay.UPI)}*
• 💳 Card (POS Swipe): *${fmt(pay.Card)}*

🧾 *TODAY'S COUNTER EXPENSES (${pettyCash.totalCount || 0}):*
${expenseLines}

🔄 *EXCHANGES & REPLACEMENTS:*
• Exchange Bills Handled: *${exch.ExchangeBills || 0}*
• Total Returned Merchandise: *${fmt(exch.ExchangeValue)}*
• Net Upsell Collected: *${(exch.NetUpsellDiff || 0) >= 0 ? '+' : ''}${fmt(exch.NetUpsellDiff)}*

🏆 *TOP PERFORMING CATEGORY:*
• Best Seller: *${topCat.TopCategory || 'Apparel'}* (${topCat.UnitsSold || 0} units sold)
━━━━━━━━━━━━━━━━━━━━━━━━
✨ Automated EOD Store Intelligence System`;

    return {
        text,
        summary: {
            grossSales: summary.GrossSales || 0,
            billCount: summary.BillCount || 0,
            discounts: summary.TotalDiscount || 0,
            gst: summary.TaxCollected || 0,
            cash: pay.Cash || 0,
            pettyCashSpent: pettyCash.totalSpent || 0,
            netExpectedDrawerCash,
            card: pay.Card || 0,
            upi: pay.UPI || 0,
            exchangeBills: exch.ExchangeBills || 0,
            exchangeValue: exch.ExchangeValue || 0,
            upsellCollected: exch.NetUpsellDiff || 0,
            topCategory: topCat.TopCategory || 'Apparel',
            topCategoryUnits: topCat.UnitsSold || 0
        },
        recipients: EOD_DEFAULT_RECIPIENTS
    };
}

app.get('/api/reports/eod-summary', async (req, res) => {
    try {
        const report = await generateEodSummaryReport(req.query.date || null);
        res.json(report);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

async function dispatchEodReport(targetDate = null, labelSuffix = null, customRecipients = null) {
    try {
        const report = await generateEodSummaryReport(targetDate, labelSuffix);
        const targets = customRecipients && Array.isArray(customRecipients) && customRecipients.length > 0
            ? customRecipients
            : EOD_DEFAULT_RECIPIENTS;

        const results = [];
        for (const rawNumber of targets) {
            const clean = String(rawNumber).replace(/[^0-9]/g, '');
            const formatted = clean.length === 10 ? `91${clean}` : clean;
            try {
                const response = await fetch('http://localhost:3000/send', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ number: formatted, message: report.text })
                });
                const data = await response.json().catch(() => ({}));
                const ok = response.ok && !data.error;
                results.push({ number: clean, success: ok, data });
            } catch (sendErr) {
                results.push({ number: clean, success: false, error: sendErr.message });
            }
        }

        const deliveredCount = results.filter(r => r.success).length;
        if (deliveredCount > 0) {
            const dateToLog = targetDate || new Date().toLocaleDateString('en-CA');
            try {
                fs.writeFileSync(path.join(__dirname, 'sent_eod_date.txt'), dateToLog, 'utf8');
            } catch (e) {}
            console.log(`[EOD DISPATCH] Successfully delivered EOD digest for ${dateToLog} to ${deliveredCount}/${targets.length} recipients.`);
            return { success: true, results, report: report.text, deliveredCount };
        } else {
            console.warn(`[EOD DISPATCH WARNING] No recipients successfully received EOD digest. sent_eod_date.txt NOT updated.`);
            return { success: false, results, report: report.text, deliveredCount: 0 };
        }
    } catch (err) {
        console.error('[EOD DISPATCH ERROR]:', err.message);
        return { success: false, error: err.message };
    }
}

app.post('/api/reports/eod-summary/send', async (req, res) => {
    try {
        const result = await dispatchEodReport(req.body?.date || null, null, req.body?.recipients || null);
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 3. Size Matrix & Inventory Heatmap Endpoint
app.get('/api/inventory/size-matrix', async (req, res) => {
    try {
        const result = await sql.query(`
            SELECT TOP 300
                ISNULL(f.SECTION_NAME, 'Apparel') as Category,
                ISNULL(d.ARTICLE_NAME, 'General Article') as ArticleName,
                ISNULL(s.para2_name, 'Standard') as Size,
                SUM(a.QUANTITY) as UnitsSold,
                SUM(a.NET) as TotalRevenue,
                COUNT(DISTINCT a.CM_ID) as Invoices
            FROM CMD01106 a WITH (NOLOCK)
            JOIN CMM01106 m WITH (NOLOCK) ON a.CM_ID = m.CM_ID
            JOIN SKU c WITH (NOLOCK) ON a.PRODUCT_CODE = c.PRODUCT_CODE
            JOIN ARTICLE d WITH (NOLOCK) ON c.ARTICLE_CODE = d.ARTICLE_CODE
            LEFT JOIN SECTIOND e WITH (NOLOCK) ON d.SUB_SECTION_CODE = e.SUB_SECTION_CODE
            LEFT JOIN SECTIONM f WITH (NOLOCK) ON e.SECTION_CODE = f.SECTION_CODE
            LEFT JOIN SKU_NAMES s WITH (NOLOCK) ON a.PRODUCT_CODE = s.product_Code
            WHERE m.CANCELLED = 0 AND m.CM_TIME >= DATEADD(day, -90, GETDATE())
            GROUP BY f.SECTION_NAME, d.ARTICLE_NAME, s.para2_name
            HAVING SUM(a.QUANTITY) > 0
            ORDER BY TotalRevenue DESC
        `);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 3. Customer Wardrobe Profiler Endpoint
app.get('/api/analytics/wardrobe-profiles', async (req, res) => {
    try {
        const result = await sql.query(`
            ;WITH TopCust AS (
                SELECT TOP 100
                    A.CUSTOMER_CODE as Phone,
                    MAX(ISNULL(B.CUSTOMER_FNAME, '') + ' ' + ISNULL(B.CUSTOMER_LNAME, '')) as CustomerName,
                    SUM(A.NET_AMOUNT) as TotalSpent,
                    COUNT(A.CM_ID) as TotalVisits,
                    MAX(A.CM_TIME) as LastVisitTime
                FROM CMM01106 A WITH (NOLOCK)
                JOIN CUSTDYM B WITH (NOLOCK) ON B.CUSTOMER_CODE = A.CUSTOMER_CODE
                WHERE A.CANCELLED = 0 AND A.CUSTOMER_CODE IS NOT NULL AND A.CUSTOMER_CODE <> '' AND A.CUSTOMER_CODE <> '2222222222'
                GROUP BY A.CUSTOMER_CODE
                HAVING SUM(A.NET_AMOUNT) > 0
                ORDER BY TotalSpent DESC
            )
            SELECT 
                tc.Phone,
                tc.CustomerName,
                tc.TotalSpent,
                tc.TotalVisits,
                CONVERT(varchar, tc.LastVisitTime, 126) as LastVisitDate,
                DATEDIFF(day, tc.LastVisitTime, GETDATE()) as DaysInactive,
                ISNULL(det.FormalItems, 0) as FormalItems,
                ISNULL(det.CasualItems, 0) as CasualItems
            FROM TopCust tc
            OUTER APPLY (
                SELECT 
                    SUM(CASE WHEN f.SECTION_NAME LIKE '%FORMAL%' OR d.ARTICLE_NAME LIKE '%SHIRT%' THEN 1 ELSE 0 END) as FormalItems,
                    SUM(CASE WHEN f.SECTION_NAME LIKE '%JEANS%' OR f.SECTION_NAME LIKE '%SM%' OR d.ARTICLE_NAME LIKE '%T SHIRT%' THEN 1 ELSE 0 END) as CasualItems
                FROM CMM01106 m WITH (NOLOCK)
                JOIN CMD01106 cd WITH (NOLOCK) ON m.CM_ID = cd.CM_ID
                JOIN SKU c WITH (NOLOCK) ON cd.PRODUCT_CODE = c.PRODUCT_CODE
                JOIN ARTICLE d WITH (NOLOCK) ON c.ARTICLE_CODE = d.ARTICLE_CODE
                LEFT JOIN SECTIOND e WITH (NOLOCK) ON d.SUB_SECTION_CODE = e.SUB_SECTION_CODE
                LEFT JOIN SECTIONM f WITH (NOLOCK) ON e.SECTION_CODE = f.SECTION_CODE
                WHERE m.CUSTOMER_CODE = tc.Phone AND m.CANCELLED = 0
            ) det
            ORDER BY tc.TotalSpent DESC
        `);

        const enriched = result.recordset.map(c => {
            const formal = c.FormalItems || 0;
            const casual = c.CasualItems || 0;
            let primaryStyle = formal > casual ? 'Formal Suits & Shirts' : 'Casual Polos & Denims';
            let persona = 'Standard Shopper';
            if (c.TotalSpent >= 50000) persona = '💎 High Roller VIP';
            else if (c.TotalVisits >= 3) persona = '⚡ Frequent Loyal VIP';
            else if (formal > casual) persona = '💼 Formal Wearer';
            else persona = '👕 Casual Trendsetter';

            return {
                ...c,
                PrimaryStyle: primaryStyle,
                Persona: persona
            };
        });

        res.json(enriched);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 4. Monthly Store Profit & Loss (P&L) & Lifetime Sales Endpoint
app.get('/api/financials/pnl', async (req, res) => {
    try {
        const batchQuery = await sql.query(`
            -- 1. Current Month Sales
            DECLARE @startOfMonth DATETIME = DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1);
            SELECT 
                ISNULL(SUM(NET_AMOUNT), 0) as GrossSales,
                ISNULL(SUM(TOTAL_GST_AMOUNT), 0) as TotalTax,
                COUNT(CM_ID) as TotalBills
            FROM CMM01106 WITH (NOLOCK)
            WHERE CM_TIME >= @startOfMonth AND CANCELLED = 0;

            -- 2. Lifetime Store Sales
            SELECT 
                ISNULL(SUM(NET_AMOUNT), 0) as LifetimeGrossSales,
                ISNULL(SUM(TOTAL_GST_AMOUNT), 0) as LifetimeTax,
                COUNT(CM_ID) as LifetimeBills,
                MIN(CM_TIME) as FirstSaleDate,
                MAX(CM_TIME) as LastSaleDate
            FROM CMM01106 WITH (NOLOCK)
            WHERE CANCELLED = 0;

            -- 3. Monthly Sales History
            SELECT 
                CONVERT(varchar(7), CM_TIME, 120) as MonthKey,
                YEAR(CM_TIME) as Year,
                MONTH(CM_TIME) as Month,
                ISNULL(SUM(NET_AMOUNT), 0) as GrossSales,
                ISNULL(SUM(TOTAL_GST_AMOUNT), 0) as TotalTax,
                COUNT(CM_ID) as TotalBills
            FROM CMM01106 WITH (NOLOCK)
            WHERE CANCELLED = 0
            GROUP BY CONVERT(varchar(7), CM_TIME, 120), YEAR(CM_TIME), MONTH(CM_TIME)
            ORDER BY MonthKey DESC;
        `);

        // Franchise Retail P&L Model Standard Costs
        const rent = 40000;
        const electricity = 15000;
        const staffSalaries = 45000;
        const miscExpenses = 10000;
        const totalExpenses = 110000; // As requested

        const monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];

        // 1. Current Month Metrics
        const currentSales = batchQuery.recordsets[0]?.[0]?.GrossSales || 0;
        const currentTax = batchQuery.recordsets[0]?.[0]?.TotalTax || 0;
        const currentTaxable = currentSales - currentTax;
        const currentBills = batchQuery.recordsets[0]?.[0]?.TotalBills || 0;
        const currentGrossProfit = Math.round(currentTaxable * 0.27);
        const currentCogs = currentTaxable - currentGrossProfit;
        const currentNetProfit = currentGrossProfit - totalExpenses;
        const currentMarginPct = currentSales > 0 ? Math.round((currentNetProfit / currentSales) * 100) : 0;

        // 2. Lifetime Metrics
        const ltRecord = batchQuery.recordsets[1]?.[0] || {};
        const ltSales = ltRecord.LifetimeGrossSales || 0;
        const ltTax = ltRecord.LifetimeTax || 0;
        const ltTaxable = ltSales - ltTax;
        const ltBills = ltRecord.LifetimeBills || 0;
        const ltGrossProfit = Math.round(ltTaxable * 0.27);
        const ltCogs = ltTaxable - ltGrossProfit;
        const ltAvgBill = ltBills > 0 ? Math.round(ltSales / ltBills) : 0;

        // 3. Each Month Sales Breakdown
        const monthlyRows = batchQuery.recordsets[2] || [];
        const monthlySales = monthlyRows.map(row => {
            const mSales = row.GrossSales || 0;
            const mTax = row.TotalTax || 0;
            const mTaxable = mSales - mTax;
            const mBills = row.TotalBills || 0;
            const mGrossProfit = Math.round(mTaxable * 0.27);
            const mCogs = mTaxable - mGrossProfit;
            const mNetProfit = mGrossProfit - totalExpenses;
            const mMarginPct = mSales > 0 ? Math.round((mNetProfit / mSales) * 100) : 0;
            const mAvgBill = mBills > 0 ? Math.round(mSales / mBills) : 0;
            const monthLabel = `${monthNames[row.Month - 1] || ''} ${row.Year}`;

            return {
                monthKey: row.MonthKey,
                monthName: monthLabel,
                year: row.Year,
                month: row.Month,
                grossSales: mSales,
                taxCollected: mTax,
                taxableRevenue: mTaxable,
                costOfGoodsSold: mCogs,
                grossProfit: mGrossProfit,
                totalBills: mBills,
                avgBillValue: mAvgBill,
                operatingExpenses: {
                    rent,
                    electricity,
                    staffSalaries,
                    miscExpenses,
                    totalExpenses
                },
                netStoreProfit: mNetProfit,
                profitMarginPct: mMarginPct
            };
        });

        // Cumulative active months
        const activeMonthsCount = monthlySales.length || 1;
        const ltExpenses = totalExpenses * activeMonthsCount;
        const ltNetProfit = ltGrossProfit - ltExpenses;
        const ltMarginPct = ltSales > 0 ? Math.round((ltNetProfit / ltSales) * 100) : 0;

        const now = new Date();
        const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        const currentMonthName = `${monthNames[now.getMonth()]} ${now.getFullYear()}`;

        res.json({
            // Current month (preserves existing contract)
            grossSales: currentSales,
            taxCollected: currentTax,
            taxableRevenue: currentTaxable,
            costOfGoodsSold: currentCogs,
            grossProfit: currentGrossProfit,
            totalBills: currentBills,
            avgBillValue: currentBills > 0 ? Math.round(currentSales / currentBills) : 0,
            operatingExpenses: {
                rent,
                electricity,
                staffSalaries,
                miscExpenses,
                totalExpenses
            },
            netStoreProfit: currentNetProfit,
            profitMarginPct: currentMarginPct,
            currentMonthKey,
            currentMonthName,

            // Lifetime telemetry
            lifetime: {
                grossSales: ltSales,
                taxCollected: ltTax,
                taxableRevenue: ltTaxable,
                costOfGoodsSold: ltCogs,
                grossProfit: ltGrossProfit,
                totalBills: ltBills,
                avgBillValue: ltAvgBill,
                firstSaleDate: ltRecord.FirstSaleDate,
                lastSaleDate: ltRecord.LastSaleDate,
                activeMonthsCount,
                totalOperatingExpenses: ltExpenses,
                netStoreProfit: ltNetProfit,
                profitMarginPct: ltMarginPct
            },

            // Month-by-month history
            monthlySales
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 5. Repeat Customer Retention Radar Endpoint
app.get('/api/analytics/retention-radar', async (req, res) => {
    try {
        const batchQuery = `
            ;WITH CustSummary AS (
                SELECT 
                    A.CUSTOMER_CODE as Phone,
                    MAX(ISNULL(B.CUSTOMER_FNAME, '') + ' ' + ISNULL(B.CUSTOMER_LNAME, '')) as CustomerName,
                    SUM(A.NET_AMOUNT) as TotalSpent,
                    COUNT(A.CM_ID) as TotalVisits,
                    MAX(A.CM_TIME) as MaxTime,
                    DATEDIFF(day, MAX(A.CM_TIME), GETDATE()) as DaysInactive
                FROM CMM01106 A WITH (NOLOCK)
                JOIN CUSTDYM B WITH (NOLOCK) ON B.CUSTOMER_CODE = A.CUSTOMER_CODE
                WHERE A.CANCELLED = 0 AND A.CUSTOMER_CODE IS NOT NULL AND A.CUSTOMER_CODE <> '' AND A.CUSTOMER_CODE <> '2222222222'
                GROUP BY A.CUSTOMER_CODE
            )
            SELECT 
                COUNT(*) as TotalCustomers,
                SUM(CASE WHEN TotalVisits > 1 THEN 1 ELSE 0 END) as RepeatCustomers,
                AVG(TotalSpent) as AvgLtv
            FROM CustSummary;

            ;WITH CustSummary AS (
                SELECT 
                    A.CUSTOMER_CODE as Phone,
                    MAX(ISNULL(B.CUSTOMER_FNAME, '') + ' ' + ISNULL(B.CUSTOMER_LNAME, '')) as CustomerName,
                    SUM(A.NET_AMOUNT) as TotalSpent,
                    COUNT(A.CM_ID) as TotalVisits,
                    CONVERT(varchar, MAX(A.CM_TIME), 126) as LastVisitDate,
                    DATEDIFF(day, MAX(A.CM_TIME), GETDATE()) as DaysInactive
                FROM CMM01106 A WITH (NOLOCK)
                JOIN CUSTDYM B WITH (NOLOCK) ON B.CUSTOMER_CODE = A.CUSTOMER_CODE
                WHERE A.CANCELLED = 0 AND A.CUSTOMER_CODE IS NOT NULL AND A.CUSTOMER_CODE <> '' AND A.CUSTOMER_CODE <> '2222222222'
                GROUP BY A.CUSTOMER_CODE
                HAVING DATEDIFF(day, MAX(A.CM_TIME), GETDATE()) >= 15
            )
            SELECT TOP 20 *
            FROM CustSummary
            ORDER BY TotalSpent DESC;

            ;WITH CustSummary AS (
                SELECT 
                    A.CUSTOMER_CODE as Phone,
                    MAX(ISNULL(B.CUSTOMER_FNAME, '') + ' ' + ISNULL(B.CUSTOMER_LNAME, '')) as CustomerName,
                    SUM(A.NET_AMOUNT) as TotalSpent,
                    COUNT(A.CM_ID) as TotalVisits,
                    CONVERT(varchar, MAX(A.CM_TIME), 126) as LastVisitDate,
                    MAX(A.CM_TIME) as MaxTime
                FROM CMM01106 A WITH (NOLOCK)
                JOIN CUSTDYM B WITH (NOLOCK) ON B.CUSTOMER_CODE = A.CUSTOMER_CODE
                WHERE A.CANCELLED = 0 AND A.CUSTOMER_CODE IS NOT NULL AND A.CUSTOMER_CODE <> '' AND A.CUSTOMER_CODE <> '2222222222'
                GROUP BY A.CUSTOMER_CODE
                HAVING COUNT(A.CM_ID) > 1
            )
            SELECT TOP 20 Phone, CustomerName, TotalSpent, TotalVisits, LastVisitDate
            FROM CustSummary
            ORDER BY MaxTime DESC;
        `;

        const result = await sql.query(batchQuery);
        const summary = result.recordsets[0] || [];
        const overdueVips = result.recordsets[1] || [];
        const recentRepeatBuyers = (result.recordsets[2] || []).map(b => ({ ...b, Bills: [] }));

        const totalCust = summary[0]?.TotalCustomers || 1;
        const repeatCust = summary[0]?.RepeatCustomers || 0;
        const repeatRatePct = Math.round((repeatCust / totalCust) * 100);

        res.json({
            totalCustomers: totalCust,
            repeatCustomers: repeatCust,
            repeatRatePct: repeatRatePct,
            avgLtv: summary[0]?.AvgLtv || 0,
            overdueVips: overdueVips,
            recentRepeatBuyers: recentRepeatBuyers
        });
    } catch (err) {
        console.error("Retention Radar Error:", err);
        res.status(500).json({ error: err.message });
    }
});

// 6. EOD Cash Reconciliation Endpoints
const RECON_FILE = path.join(__dirname, 'reconciliations.json');

app.get('/api/reconciliation/latest', (req, res) => {
    try {
        if (fs.existsSync(RECON_FILE)) {
            const data = JSON.parse(fs.readFileSync(RECON_FILE, 'utf8'));
            return res.json(data[data.length - 1] || null);
        }
        res.json(null);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/reconciliation/save', (req, res) => {
    try {
        const { systemCash, countedCash, variance, notes, managerName } = req.body;
        let records = [];
        if (fs.existsSync(RECON_FILE)) {
            records = JSON.parse(fs.readFileSync(RECON_FILE, 'utf8'));
        }
        const newRecord = {
            id: Date.now(),
            date: new Date().toISOString(),
            systemCash,
            countedCash,
            variance,
            notes,
            managerName: managerName || 'Manager'
        };
        records.push(newRecord);
        fs.writeFileSync(RECON_FILE, JSON.stringify(records, null, 2));
        res.json({ success: true, record: newRecord });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});



app.post('/api/ai/vm-audit', upload.array('images', 5), async (req, res) => {
    try {
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ error: "No image files provided." });
        }

        const model = getAiModel();

        const parts = [];
        
        // Add images to the parts array
        for (const file of req.files) {
            const imageBuffer = fs.readFileSync(file.path);
            const base64Image = imageBuffer.toString('base64');
            parts.push({
                inlineData: {
                    data: base64Image,
                    mimeType: file.mimetype
                }
            });
        }

        const prompt = `You are a Visual Merchandising Auditor for COBB retail clothing stores.
Analyze these store display photos (e.g. mannequin layout, hanger racks, folded display shelves, window displays).
You must return a raw JSON response (without markdown code blocks or wrapping) containing the compliance audit result.
The JSON must follow this exact structure:
{
  "score": 82,
  "metrics": {
    "colorHarmony": 85,
    "sizingOrder": 70,
    "accessibility": 90,
    "density": 75
  },
  "critiques": [
    "One critique point about what is wrong or needs improvement",
    "Another critique point..."
  ],
  "recommendations": [
    "Actionable step to fix the critiques",
    "Another suggestion..."
  ]
}
Be realistic, critical, and constructive based on standard visual merchandising principles. Return only the raw JSON.`;

        parts.push(prompt);

        const result = await model.generateContent(parts);

        const textResponse = result.response.text().trim();
        const cleanJson = textResponse.replace(/^```json\s*/i, '').replace(/```$/, '').trim();
        const auditResult = JSON.parse(cleanJson);

        try {
            for (const file of req.files) {
                fs.unlinkSync(file.path);
            }
        } catch (e) {}

        res.json(auditResult);
    } catch (err) {
        console.error("VM Audit failed:", err);
        res.status(500).json({ error: err.message || "Visual Merchandising Audit failed" });
    }
});

app.get('/api/smart-bundles', async (req, res) => {
    try {
        let slowItems = [];
        try {
            const queryRes = await sql.query(`
                SELECT TOP 5
                    s.article_no AS ArticleNo,
                    MAX(ISNULL(s.article_name, s.section_name)) AS ArticleName,
                    MAX(s.section_name) AS Category
                FROM PMT01106 p WITH (NOLOCK)
                INNER JOIN SKU_NAMES s WITH (NOLOCK) ON p.product_code = s.product_Code
                WHERE p.quantity_in_stock > 0
                GROUP BY s.article_no
                ORDER BY COUNT(DISTINCT s.product_Code) DESC
            `);
            slowItems = queryRes.recordset;
        } catch (e) {
            console.error("DB query for slow items failed, using fallbacks:", e);
        }

        const staticBundles = [
            {
                id: "b1",
                name: "Summer Formal Styling Set",
                items: [
                    { name: "Cobb Slim-Fit Cotton White Shirt", category: "Formal Shirts", originalPrice: 1499, isSlow: false },
                    { name: "Cobb Charcoal Grey Trouser", category: "Formal Trousers", originalPrice: 2299, isSlow: true, reason: "Slow moving size/color" }
                ],
                originalPrice: 3798,
                bundlePrice: 2999,
                discountPct: 21,
                marginImpact: "-5.2%",
                velocityBoost: "+45%"
            },
            {
                id: "b2",
                name: "Weekend Denim Combo",
                items: [
                    { name: "Cobb Casual Indigo Jeans", category: "Denim Jeans", originalPrice: 2499, isSlow: false },
                    { name: "Cobb Polo Graphic Tee", category: "T-Shirts", originalPrice: 999, isSlow: true, reason: "Overstocked color" }
                ],
                originalPrice: 3498,
                bundlePrice: 2699,
                discountPct: 23,
                marginImpact: "-4.8%",
                velocityBoost: "+60%"
            },
            {
                id: "b3",
                name: "Business Casual Ensemble",
                items: [
                    { name: "Cobb Premium Blazer Navy", category: "Suits & Blazers", originalPrice: 4999, isSlow: false },
                    { name: "Cobb Olive Smart Chino", category: "Chinos", originalPrice: 1999, isSlow: true, reason: "Slow moving size/color" }
                ],
                originalPrice: 6998,
                bundlePrice: 5299,
                discountPct: 24,
                marginImpact: "-6.0%",
                velocityBoost: "+35%"
            }
        ];

        if (slowItems && slowItems.length > 0) {
            slowItems.forEach((slowItem, index) => {
                if (index < staticBundles.length) {
                    const bundle = staticBundles[index];
                    const itemToReplace = bundle.items.find(i => i.isSlow);
                    if (itemToReplace) {
                        itemToReplace.name = `${slowItem.ArticleName} (${slowItem.ArticleNo})`;
                        itemToReplace.category = slowItem.Category;
                    }
                }
            });
        }

        res.json(staticBundles);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/ai/trend-forecast', async (req, res) => {
    try {
        // Query top current stock
        const stockRes = await sql.query(`
            SELECT TOP 50 
                ISNULL(s.article_name, s.section_name) as ItemName,
                s.section_name as Category,
                s.para1_name as Color,
                SUM(p.quantity_in_stock) as CurrentStock
            FROM PMT01106 p
            INNER JOIN SKU_NAMES s ON p.product_code = s.product_Code
            WHERE p.quantity_in_stock > 0
            GROUP BY ISNULL(s.article_name, s.section_name), s.section_name, s.para1_name
            ORDER BY CurrentStock DESC
        `);
        const stockItems = stockRes.recordset.map(i => `${i.ItemName} (${i.Color}) - ${i.CurrentStock} in stock`).join(', ');

        // Query top recent sales
        const salesRes = await sql.query(`
            SELECT TOP 30
                MAX(RTRIM(d.ARTICLE_NAME)) as ArticleName,
                MAX(RTRIM(d.SECTION_NAME)) as Category,
                SUM(d.QUANTITY) as TotalUnitsSold
            FROM VW_CASHMEMO_PRINT_DET d WITH (NOLOCK)
            WHERE d.QUANTITY > 0
            GROUP BY d.ARTICLE_NO
            ORDER BY TotalUnitsSold DESC
        `);
        const salesItems = salesRes.recordset.map(i => `${i.ArticleName} (${i.Category}) - ${i.TotalUnitsSold} sold`).join(', ');

        const model = getAiModel();
        
        const currentDate = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

        const prompt = `You are an expert Retail Fashion Analyst for Cobb Italy (men's apparel). 
Today's date is ${currentDate}. Based on current global fashion trends for the Indian market, the current date, and our actual store data, predict the top 3 trends for the UPCOMING season (e.g., if it is August, predict for Autumn/Winter). Do not suggest trends for past years or current ending seasons.

Here is our Top Selling Items recently:
${salesItems}

Here is our Top Inventory In-Stock right now:
${stockItems}

Return a raw JSON response (no markdown) with this exact structure:
{
  "season": "Upcoming Season (e.g. Autumn/Winter 2026)",
  "trends": [
    {
      "trendName": "E.g. Earthy Tones",
      "category": "E.g. Casual Shirts",
      "predictedDemandSurge": "+45%",
      "confidenceScore": 92,
      "suggestedItems": [
        {
          "name": "Item Name (Color)",
          "suggestedPrice": "₹1,499",
          "estimatedMargin": "55%"
        }
      ]
    }
  ]
}
Ensure exactly 3 trends are returned. For each trend, provide a 'confidenceScore' between 70 and 99. The 'suggestedItems' MUST be an array of 4 objects representing specific items ACTUALLY found in the inventory or sales list above, along with a realistic retail price point for the Indian market and an estimated margin percentage. Do not hallucinate item names. Return only the JSON.`;

        const result = await model.generateContent(prompt);
        const textResponse = result.response.text().trim();
        const cleanJson = textResponse.replace(/^```json\s*/i, '').replace(/```$/, '').trim();
        const forecast = JSON.parse(cleanJson);
        
        res.json(forecast);
    } catch (err) {
        console.error("Trend forecast failed:", err);
        res.status(500).json({ error: "Failed to generate trend forecast." });
    }
});

app.post('/api/ai/whatsapp-draft', async (req, res) => {
    try {
        const { customerName, pastPurchases, stylePreferences } = req.body;
        
        const model = getAiModel();
        
        const prompt = `You are an expert retail marketer. Write a highly personalized, short WhatsApp message (max 3 sentences) for a customer named ${customerName}.
Their past purchases include: ${pastPurchases}.
Their style preference seems to be: ${stylePreferences}.
The message should inform them of a new collection arriving at Cobb Pundri that matches their style, and offer them a 10% VIP discount if they visit this week. Use emojis appropriately. DO NOT return JSON. Return only the raw message string.`;

        const result = await model.generateContent(prompt);
        res.json({ message: result.response.text().trim() });
    } catch (err) {
        console.error("WhatsApp draft failed:", err);
        res.status(500).json({ error: "Failed to generate WhatsApp draft." });
    }
});

app.post('/api/ai/competitor-intel', upload.single('image'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: "No image file provided." });
        }

        const imagePath = req.file.path;
        const imageBuffer = fs.readFileSync(imagePath);
        const base64Image = imageBuffer.toString('base64');
        const mimeType = req.file.mimetype;

        const model = getAiModel();

        const prompt = `You are a Retail Pricing Strategist. Analyze this image of a competitor's promotional flyer or advertisement.
Extract their discount strategy, and propose a counter-strategy for Cobb (our store) that matches or beats their offer while protecting our margins (we have an average 45% margin).
Return a raw JSON response (no markdown) with this exact structure:
{
  "detectedCompetitorOffer": "E.g. Flat 50% off on all jeans",
  "cobbCounterStrategy": "E.g. Buy 1 Jeans, Get 2 T-Shirts Free (perceived higher value, moves dead stock)",
  "marginImpact": "E.g. Protects margin by 12% compared to flat 50% discount",
  "executionDifficulty": "Low/Medium/High"
}
Return only the raw JSON.`;

        const result = await model.generateContent([
            {
                inlineData: {
                    data: base64Image,
                    mimeType: mimeType
                }
            },
            prompt
        ]);

        const textResponse = result.response.text().trim();
        const cleanJson = textResponse.replace(/^```json\s*/i, '').replace(/```$/, '').trim();
        const intelResult = JSON.parse(cleanJson);

        try {
            fs.unlinkSync(imagePath);
        } catch (e) {}

        res.json(intelResult);
    } catch (err) {
        console.error("Competitor Intel failed:", err);
        res.status(500).json({ error: "Failed to process competitor intelligence." });
    }
});

// ===================================================================
// FEATURE: SMART WAREHOUSE REORDER & INDENT GENERATOR
// ===================================================================

const DENOMINATION_FILE = path.join(__dirname, 'denomination_records.json');

app.get('/api/inventory/reorder-suggestions', async (req, res) => {
    try {
        const result = await sql.query(`
            ;WITH SalesVelocity AS (
                SELECT
                    s.article_no AS ArticleNo,
                    MAX(ISNULL(s.article_name, s.section_name)) AS ArticleName,
                    MAX(ISNULL(s.section_name, 'Apparel')) AS Category,
                    ISNULL(s.para2_name, 'Standard') AS Size,
                    ISNULL(s.para1_name, 'Standard') AS Color,
                    SUM(d.QUANTITY) AS UnitsSold90d,
                    CAST(SUM(d.QUANTITY) AS FLOAT) / 13.0 AS AvgWeeklySales
                FROM CMD01106 d WITH (NOLOCK)
                JOIN CMM01106 m WITH (NOLOCK) ON d.CM_ID = m.CM_ID
                JOIN SKU_NAMES s WITH (NOLOCK) ON d.PRODUCT_CODE = s.product_Code
                WHERE m.CANCELLED = 0
                  AND m.CM_TIME >= DATEADD(day, -90, GETDATE())
                GROUP BY s.article_no, s.para2_name, s.para1_name
                HAVING SUM(d.QUANTITY) > 0
            ),
            CurrentStock AS (
                SELECT
                    s.article_no AS ArticleNo,
                    ISNULL(s.para2_name, 'Standard') AS Size,
                    ISNULL(s.para1_name, 'Standard') AS Color,
                    SUM(p.quantity_in_stock) AS CurrentStock
                FROM PMT01106 p WITH (NOLOCK)
                JOIN SKU_NAMES s WITH (NOLOCK) ON p.product_code = s.product_Code
                WHERE p.quantity_in_stock >= 0
                GROUP BY s.article_no, s.para2_name, s.para1_name
            )
            SELECT TOP 200
                sv.ArticleNo,
                sv.ArticleName,
                sv.Category,
                sv.Size,
                sv.Color,
                ISNULL(cs.CurrentStock, 0) AS CurrentStock,
                sv.UnitsSold90d,
                ROUND(sv.AvgWeeklySales, 1) AS AvgWeeklySales,
                CASE WHEN sv.AvgWeeklySales > 0
                     THEN ROUND(ISNULL(cs.CurrentStock, 0) / sv.AvgWeeklySales, 1)
                     ELSE 99 END AS WeeksOfStock,
                CASE WHEN (4.0 * sv.AvgWeeklySales) - ISNULL(cs.CurrentStock, 0) > 0
                     THEN CEILING((4.0 * sv.AvgWeeklySales) - ISNULL(cs.CurrentStock, 0))
                     ELSE 0 END AS SuggestedReorder
            FROM SalesVelocity sv
            LEFT JOIN CurrentStock cs ON sv.ArticleNo = cs.ArticleNo AND sv.Size = cs.Size AND sv.Color = cs.Color
            WHERE CASE WHEN sv.AvgWeeklySales > 0
                       THEN ISNULL(cs.CurrentStock, 0) / sv.AvgWeeklySales
                       ELSE 99 END < 4
            ORDER BY CASE WHEN sv.AvgWeeklySales > 0
                          THEN ISNULL(cs.CurrentStock, 0) / sv.AvgWeeklySales
                          ELSE 99 END ASC
        `);
        res.json(result.recordset);
    } catch (err) {
        console.error('Reorder suggestions error:', err);
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/inventory/generate-indent', (req, res) => {
    try {
        const { items } = req.body;
        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({ error: 'No items provided' });
        }

        const date = new Date().toLocaleDateString('en-GB');
        const time = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
        let totalUnits = 0;

        let text = `📋 *RESTOCK INDENT — COBB PUNDRI*\n`;
        text += `Date: ${date} | Time: ${time}\n`;
        text += `──────────────────────────\n`;
        text += `Article          | Size | Qty\n`;
        text += `──────────────────────────\n`;

        items.forEach(item => {
            const name = (item.articleName || item.articleNo || 'Unknown').substring(0, 16).padEnd(16);
            const size = (item.size || '-').padEnd(4);
            const qty = String(item.qty || 0).padStart(3);
            text += `${name} | ${size} | ${qty}\n`;
            totalUnits += parseInt(item.qty) || 0;
        });

        text += `──────────────────────────\n`;
        text += `Total: ${items.length} articles, ${totalUnits} units\n\n`;
        text += `⚡ Generated by Cobb CRM\n`;
        text += `Please process and dispatch at earliest.`;

        res.json({ text, totalItems: items.length, totalUnits });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ===================================================================
// FEATURE: CASH DENOMINATION & NIGHT CLOSING SHEET
// ===================================================================

app.get('/api/reconciliation/denomination-data', async (req, res) => {
    try {
        const salesResult = await sql.query(`
            SELECT
                COUNT(m.CM_ID) AS BillCount,
                ISNULL(SUM(m.NET_AMOUNT), 0) AS GrossSales,
                ISNULL(SUM(m.TOTAL_GST_AMOUNT), 0) AS TaxCollected,
                ISNULL(SUM(m.NET_AMOUNT - m.TOTAL_GST_AMOUNT), 0) AS NetSales,
                ISNULL(SUM(p.CASH_AMOUNT), 0) AS CashAmount,
                ISNULL(SUM(p.CC_AMOUNT), 0) AS CardAmount,
                ISNULL(SUM(ISNULL(w.UPI, 0) + ISNULL(w.[Paytm QR], 0) + ISNULL(w.Paytm, 0) + ISNULL(w.[PAYTM UPI], 0) + ISNULL(w.RazorpayUPI, 0)), 0) AS UpiAmount
            FROM CMM01106 m WITH (NOLOCK)
            LEFT JOIN VW_BILL_PAYMODE p WITH (NOLOCK) ON m.CM_ID = p.MEMO_ID
            LEFT JOIN VW_WL_CASHMEMOLIST w WITH (NOLOCK) ON m.CM_ID = w.MEMO_ID
            WHERE m.CM_TIME >= CAST(GETDATE() AS DATE) AND m.CANCELLED = 0
        `);

        const summary = salesResult.recordset[0] || {};

        // Read opening cash from previous day's closing
        let openingCash = 0;
        try {
            if (fs.existsSync(DENOMINATION_FILE)) {
                const records = JSON.parse(fs.readFileSync(DENOMINATION_FILE, 'utf8'));
                if (records.length > 0) {
                    const last = records[records.length - 1];
                    openingCash = last.closingCashInDrawer || 0;
                }
            }
        } catch (e) {}

        res.json({
            billCount: summary.BillCount || 0,
            grossSales: summary.GrossSales || 0,
            netSales: summary.NetSales || 0,
            taxCollected: summary.TaxCollected || 0,
            cashAmount: summary.CashAmount || 0,
            cardAmount: summary.CardAmount || 0,
            upiAmount: summary.UpiAmount || 0,
            openingCash
        });
    } catch (err) {
        console.error('Denomination data error:', err);
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/reconciliation/denomination-save', (req, res) => {
    try {
        const { denominations, notes, managerName, openingCash, expectedCash } = req.body;

        const physicalCash =
            (parseInt(denominations['2000']) || 0) * 2000 +
            (parseInt(denominations['500']) || 0) * 500 +
            (parseInt(denominations['200']) || 0) * 200 +
            (parseInt(denominations['100']) || 0) * 100 +
            (parseInt(denominations['50']) || 0) * 50 +
            (parseInt(denominations['20']) || 0) * 20 +
            (parseInt(denominations['10']) || 0) * 10 +
            (parseFloat(denominations['coins']) || 0);

        const variance = physicalCash - (expectedCash || 0);

        const record = {
            id: Date.now(),
            date: new Date().toISOString(),
            dateFormatted: new Date().toLocaleDateString('en-GB'),
            denominations,
            physicalCash,
            openingCash: openingCash || 0,
            expectedCash: expectedCash || 0,
            variance,
            closingCashInDrawer: physicalCash,
            notes: notes || '',
            managerName: managerName || 'Manager'
        };

        let records = [];
        try {
            if (fs.existsSync(DENOMINATION_FILE)) {
                records = JSON.parse(fs.readFileSync(DENOMINATION_FILE, 'utf8'));
            }
        } catch (e) {}

        records.push(record);
        fs.writeFileSync(DENOMINATION_FILE, JSON.stringify(records, null, 2));

        // Generate WhatsApp report text
        const reportText = `💵 *NIGHT CLOSING REPORT — COBB PUNDRI*
Date: ${record.dateFormatted}

🧾 *Cash Denomination:*
• ₹2000 × ${denominations['2000'] || 0} = ₹${((parseInt(denominations['2000']) || 0) * 2000).toLocaleString('en-IN')}
• ₹500 × ${denominations['500'] || 0} = ₹${((parseInt(denominations['500']) || 0) * 500).toLocaleString('en-IN')}
• ₹200 × ${denominations['200'] || 0} = ₹${((parseInt(denominations['200']) || 0) * 200).toLocaleString('en-IN')}
• ₹100 × ${denominations['100'] || 0} = ₹${((parseInt(denominations['100']) || 0) * 100).toLocaleString('en-IN')}
• ₹50 × ${denominations['50'] || 0} = ₹${((parseInt(denominations['50']) || 0) * 50).toLocaleString('en-IN')}
• ₹20 × ${denominations['20'] || 0} = ₹${((parseInt(denominations['20']) || 0) * 20).toLocaleString('en-IN')}
• ₹10 × ${denominations['10'] || 0} = ₹${((parseInt(denominations['10']) || 0) * 10).toLocaleString('en-IN')}
• Coins: ₹${(parseFloat(denominations['coins']) || 0).toLocaleString('en-IN')}

💰 *Summary:*
• Opening Cash: ₹${(openingCash || 0).toLocaleString('en-IN')}
• Today's Cash Sales: ₹${((expectedCash || 0) - (openingCash || 0)).toLocaleString('en-IN')}
• Expected in Drawer: ₹${(expectedCash || 0).toLocaleString('en-IN')}
• Physical Count: ₹${physicalCash.toLocaleString('en-IN')}
• ${variance >= 0 ? '✅' : '🔴'} Variance: ₹${variance.toLocaleString('en-IN')} ${variance > 0 ? '(Excess)' : variance < 0 ? '(Short)' : '(Exact Match!)'}
${notes ? `\n📝 Notes: ${notes}` : ''}
👤 Verified by: ${record.managerName}

⚡ Generated by Cobb CRM`;

        // Auto-dispatch EOD closing digest to the 4 owners upon night closing save
        setTimeout(async () => {
            try {
                await dispatchEodReport(null, ' (Store Closing Digest)');
            } catch (e) {
                console.error('[AUTO EOD ON CLOSING SAVE ERROR]:', e.message);
            }
        }, 500);

        res.json({ success: true, record, reportText });
    } catch (err) {
        console.error('Denomination save error:', err);
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/reconciliation/denomination-history', (req, res) => {
    try {
        let records = [];
        if (fs.existsSync(DENOMINATION_FILE)) {
            records = JSON.parse(fs.readFileSync(DENOMINATION_FILE, 'utf8'));
        }
        // Return last 30 records, most recent first
        res.json(records.slice(-30).reverse());
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ===================================================================
// FEATURE: NO-APP CUSTOMER LOYALTY POINTS ENGINE
// ===================================================================

const LOYALTY_POINTS_PER_100 = 1; // 1 point per ₹100 spent

function computeLoyalty(lifetimeSpend) {
    const points = Math.floor(lifetimeSpend / 100) * LOYALTY_POINTS_PER_100;
    const pointsValue = points; // 1 point = ₹1

    let tier = 'Bronze';
    let nextTier = 'Silver';
    let spendToNextTier = 10000 - lifetimeSpend;
    let tierColor = '#CD7F32';

    if (lifetimeSpend >= 50000) {
        tier = 'Platinum'; nextTier = null; spendToNextTier = 0; tierColor = '#E5E4E2';
    } else if (lifetimeSpend >= 25000) {
        tier = 'Gold'; nextTier = 'Platinum'; spendToNextTier = 50000 - lifetimeSpend; tierColor = '#FFD700';
    } else if (lifetimeSpend >= 10000) {
        tier = 'Silver'; nextTier = 'Gold'; spendToNextTier = 25000 - lifetimeSpend; tierColor = '#C0C0C0';
    }

    return { points, pointsValue, tier, nextTier, spendToNextTier: Math.max(0, spendToNextTier), tierColor };
}

app.get('/api/loyalty/customer/:phone', async (req, res) => {
    try {
        const phone = req.params.phone;
        const result = await sql.query(`
            SELECT
                A.CUSTOMER_CODE AS Phone,
                MAX(ISNULL(B.CUSTOMER_FNAME, '') + ' ' + ISNULL(B.CUSTOMER_LNAME, '')) AS CustomerName,
                ISNULL(SUM(A.NET_AMOUNT), 0) AS LifetimeSpend,
                COUNT(A.CM_ID) AS TotalVisits,
                MAX(A.CM_TIME) AS LastVisit,
                MIN(A.CM_TIME) AS FirstVisit
            FROM CMM01106 A WITH (NOLOCK)
            JOIN CUSTDYM B WITH (NOLOCK) ON B.CUSTOMER_CODE = A.CUSTOMER_CODE
            WHERE A.CANCELLED = 0 AND A.CUSTOMER_CODE = '${phone.replace(/'/g, "''")}'
            GROUP BY A.CUSTOMER_CODE
        `);

        if (!result.recordset || result.recordset.length === 0) {
            return res.status(404).json({ error: 'Customer not found' });
        }

        const cust = result.recordset[0];
        const loyalty = computeLoyalty(cust.LifetimeSpend);

        res.json({
            phone: cust.Phone,
            customerName: (cust.CustomerName || '').trim(),
            lifetimeSpend: cust.LifetimeSpend,
            totalVisits: cust.TotalVisits,
            lastVisit: cust.LastVisit,
            memberSince: cust.FirstVisit,
            ...loyalty
        });
    } catch (err) {
        console.error('Loyalty customer error:', err);
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/loyalty/leaderboard', async (req, res) => {
    try {
        const result = await sql.query(`
            SELECT TOP 50
                A.CUSTOMER_CODE AS Phone,
                MAX(ISNULL(B.CUSTOMER_FNAME, '') + ' ' + ISNULL(B.CUSTOMER_LNAME, '')) AS CustomerName,
                ISNULL(SUM(A.NET_AMOUNT), 0) AS LifetimeSpend,
                COUNT(A.CM_ID) AS TotalVisits,
                MAX(A.CM_TIME) AS LastVisit,
                MIN(A.CM_TIME) AS FirstVisit
            FROM CMM01106 A WITH (NOLOCK)
            JOIN CUSTDYM B WITH (NOLOCK) ON B.CUSTOMER_CODE = A.CUSTOMER_CODE
            WHERE A.CANCELLED = 0
              AND A.CUSTOMER_CODE IS NOT NULL
              AND A.CUSTOMER_CODE <> ''
              AND A.CUSTOMER_CODE <> '2222222222'
            GROUP BY A.CUSTOMER_CODE
            HAVING SUM(A.NET_AMOUNT) > 0
            ORDER BY SUM(A.NET_AMOUNT) DESC
        `);

        const leaderboard = result.recordset.map(cust => ({
            phone: cust.Phone,
            customerName: (cust.CustomerName || '').trim(),
            lifetimeSpend: cust.LifetimeSpend,
            totalVisits: cust.TotalVisits,
            lastVisit: cust.LastVisit,
            memberSince: cust.FirstVisit,
            ...computeLoyalty(cust.LifetimeSpend)
        }));

        res.json(leaderboard);
    } catch (err) {
        console.error('Loyalty leaderboard error:', err);
        res.status(500).json({ error: err.message });
    }
});

// Public-facing loyalty card HTML page (shareable via WhatsApp link)
app.get('/api/loyalty/card/:phone', async (req, res) => {
    try {
        const phone = req.params.phone;
        const result = await sql.query(`
            SELECT
                A.CUSTOMER_CODE AS Phone,
                MAX(ISNULL(B.CUSTOMER_FNAME, '') + ' ' + ISNULL(B.CUSTOMER_LNAME, '')) AS CustomerName,
                ISNULL(SUM(A.NET_AMOUNT), 0) AS LifetimeSpend,
                COUNT(A.CM_ID) AS TotalVisits,
                MAX(A.CM_TIME) AS LastVisit,
                MIN(A.CM_TIME) AS FirstVisit
            FROM CMM01106 A WITH (NOLOCK)
            JOIN CUSTDYM B WITH (NOLOCK) ON B.CUSTOMER_CODE = A.CUSTOMER_CODE
            WHERE A.CANCELLED = 0 AND A.CUSTOMER_CODE = '${phone.replace(/'/g, "''")}'
            GROUP BY A.CUSTOMER_CODE
        `);

        if (!result.recordset || result.recordset.length === 0) {
            return res.status(404).send('<h1>Customer not found</h1>');
        }

        const cust = result.recordset[0];
        const loyalty = computeLoyalty(cust.LifetimeSpend);
        const name = (cust.CustomerName || '').trim() || 'Valued Customer';
        const memberSince = cust.FirstVisit ? new Date(cust.FirstVisit).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' }) : 'N/A';
        const lastVisit = cust.LastVisit ? new Date(cust.LastVisit).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : 'N/A';

        const tierGradients = {
            Bronze: 'linear-gradient(135deg, #8B4513, #CD7F32, #DAA520)',
            Silver: 'linear-gradient(135deg, #708090, #C0C0C0, #E8E8E8)',
            Gold: 'linear-gradient(135deg, #B8860B, #FFD700, #FFF8DC)',
            Platinum: 'linear-gradient(135deg, #2C2C2C, #708090, #E5E4E2)'
        };

        const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cobb VIP Card — ${name}</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #0f172a; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .card { width: 100%; max-width: 400px; border-radius: 24px; overflow: hidden; box-shadow: 0 25px 50px rgba(0,0,0,0.5); }
        .card-top { background: ${tierGradients[loyalty.tier]}; padding: 32px 24px 24px; position: relative; }
        .card-top::after { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: radial-gradient(circle at 80% 20%, rgba(255,255,255,0.15), transparent 50%); }
        .brand { font-size: 28px; font-weight: 900; color: rgba(255,255,255,0.95); letter-spacing: 6px; text-transform: uppercase; position: relative; z-index: 1; }
        .tier-badge { display: inline-block; padding: 4px 16px; background: rgba(0,0,0,0.25); border-radius: 20px; font-size: 11px; font-weight: 700; color: white; letter-spacing: 3px; text-transform: uppercase; margin-top: 8px; position: relative; z-index: 1; }
        .customer-name { font-size: 20px; font-weight: 700; color: white; margin-top: 20px; position: relative; z-index: 1; }
        .member-since { font-size: 12px; color: rgba(255,255,255,0.7); margin-top: 4px; position: relative; z-index: 1; }
        .card-bottom { background: #1e293b; padding: 24px; }
        .points-display { text-align: center; padding: 20px 0; }
        .points-number { font-size: 48px; font-weight: 900; background: ${tierGradients[loyalty.tier]}; -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .points-label { font-size: 13px; color: #94a3b8; font-weight: 600; letter-spacing: 2px; text-transform: uppercase; margin-top: 4px; }
        .points-value { font-size: 16px; color: #22c55e; font-weight: 700; margin-top: 8px; }
        .stats { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin-top: 16px; }
        .stat { text-align: center; padding: 12px; background: #0f172a; border-radius: 12px; }
        .stat-value { font-size: 18px; font-weight: 700; color: white; }
        .stat-label { font-size: 10px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; margin-top: 4px; }
        ${loyalty.nextTier ? `.next-tier { text-align: center; margin-top: 16px; padding: 12px; background: #0f172a; border-radius: 12px; font-size: 13px; color: #94a3b8; }
        .next-tier strong { color: #f59e0b; }` : ''}
        .footer { text-align: center; margin-top: 16px; font-size: 11px; color: #475569; }
    </style>
</head>
<body>
    <div class="card">
        <div class="card-top">
            <div class="brand">COBB</div>
            <div class="tier-badge">${loyalty.tier} Member</div>
            <div class="customer-name">${name}</div>
            <div class="member-since">Member since ${memberSince}</div>
        </div>
        <div class="card-bottom">
            <div class="points-display">
                <div class="points-number">${loyalty.points.toLocaleString('en-IN')}</div>
                <div class="points-label">Loyalty Points</div>
                <div class="points-value">Worth ₹${loyalty.pointsValue.toLocaleString('en-IN')}</div>
            </div>
            <div class="stats">
                <div class="stat">
                    <div class="stat-value">₹${Math.round(cust.LifetimeSpend).toLocaleString('en-IN')}</div>
                    <div class="stat-label">Total Spent</div>
                </div>
                <div class="stat">
                    <div class="stat-value">${cust.TotalVisits}</div>
                    <div class="stat-label">Visits</div>
                </div>
                <div class="stat">
                    <div class="stat-value">${lastVisit}</div>
                    <div class="stat-label">Last Visit</div>
                </div>
            </div>
            ${loyalty.nextTier ? `<div class="next-tier">Spend <strong>₹${loyalty.spendToNextTier.toLocaleString('en-IN')}</strong> more to unlock <strong>${loyalty.nextTier}</strong></div>` : ''}
            <div class="footer">Show this card at checkout to earn & redeem points • Cobb Pundri</div>
        </div>
    </div>
</body>
</html>`;

        res.setHeader('Content-Type', 'text/html');
        res.send(html);
    } catch (err) {
        console.error('Loyalty card error:', err);
        res.status(500).send('<h1>Error loading loyalty card</h1>');
    }
});

let cloudSyncProcess = null;
function startCloudSyncHelper() {
    if (cloudSyncProcess) return true;
    const scriptPath = path.join(__dirname, 'cloud_sync.js');
    if (!fs.existsSync(scriptPath)) return false;
    try {
        cloudSyncProcess = spawn('node', ['cloud_sync.js'], { 
            cwd: __dirname, 
            shell: false, 
            windowsHide: true,
            stdio: 'ignore' 
        });
        cloudSyncProcess.on('close', () => { cloudSyncProcess = null; });
        console.log("Auto-spawned Cloud Sync Agent silently.");
    } catch (e) {}
    return true;
}

// --- PILLAR 2: INBOUND WHATSAPP ALERTS & CONCIERGE BRIDGE ---
const inboundAlerts = [];

app.post('/api/whatsapp/inbound-alert', (req, res) => {
    const { phone, message, type } = req.body || {};
    const alert = {
        id: Date.now(),
        phone: phone || 'Unknown',
        message: message || '',
        type: type || 'general',
        timestamp: new Date().toISOString(),
        status: 'unread'
    };
    inboundAlerts.unshift(alert);
    if (inboundAlerts.length > 100) inboundAlerts.pop();
    console.log(`[INBOUND ALERT] Logged ${type} from ${phone}: "${message}"`);
    res.json({ success: true, alert });
});

app.get('/api/whatsapp/inbound-alerts', (req, res) => {
    res.json(inboundAlerts);
});

app.post('/api/whatsapp/inbound-alerts/mark-read', (req, res) => {
    const { id } = req.body || {};
    const target = inboundAlerts.find(a => a.id === id);
    if (target) target.status = 'read';
    res.json({ success: true });
});

// --- PILLAR 2: GOOGLE REVIEW BOOSTER DISPATCHER ---
app.post('/api/review-booster/send', async (req, res) => {
    const { phone, customerName } = req.body || {};
    if (!phone) return res.status(400).json({ error: 'Phone number required' });
    const name = customerName || 'Valued Customer';
    const message = `✨ Hello *${name}*! 👋\n\nThank you for shopping at *Cobb Apparels* today! 🛍️\n\nHow was your in-store experience? We would love your rating:\n\n⭐ *Reply 5* for Excellent\n⭐ *Reply 4* for Good\n⭐ *Reply 1-3* for Suggestions\n\nYour feedback helps us continuously improve! 🙏`;
    try {
        const formatted = String(phone).replace(/[^0-9]/g, '');
        const finalPhone = formatted.length === 10 ? `91${formatted}` : formatted;
        await fetch('http://localhost:3000/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ number: finalPhone, message })
        });
        res.json({ success: true, message: 'Review booster dispatched' });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// --- PILLAR 2: BIRTHDAY & ANNIVERSARY GREETINGS SCHEDULER ---
app.get('/api/crm/anniversaries-today', async (req, res) => {
    try {
        const today = new Date();
        const month = String(today.getMonth() + 1).padStart(2, '0');
        const day = String(today.getDate()).padStart(2, '0');

        const result = await sql.query(`
            SELECT TOP 50
                CUSTOMER_CODE AS Phone,
                ISNULL(CUSTOMER_FNAME, '') + ' ' + ISNULL(CUSTOMER_LNAME, '') AS CustomerName,
                DOB,
                ANNIVERSARY
            FROM CUSTDYM WITH (NOLOCK)
            WHERE (
                (DOB IS NOT NULL AND FORMAT(DOB, 'MM-dd') = '${month}-${day}')
                OR
                (ANNIVERSARY IS NOT NULL AND FORMAT(ANNIVERSARY, 'MM-dd') = '${month}-${day}')
            )
            AND CUSTOMER_CODE IS NOT NULL AND LEN(CUSTOMER_CODE) >= 10
        `);
        res.json(result.recordset || []);
    } catch (e) {
        res.json([]);
    }
});

app.post('/api/crm/dispatch-wishes', async (req, res) => {
    const { phone, customerName, occasion } = req.body || {};
    if (!phone) return res.status(400).json({ error: 'Phone required' });
    const isBirthday = occasion === 'birthday' || !occasion;
    const emoji = isBirthday ? '🎂🎉' : '💍💐';
    const title = isBirthday ? 'Happy Birthday' : 'Happy Anniversary';
    const code = isBirthday ? `COBB-BDAY-${new Date().getFullYear()}` : `COBB-CELEB-${new Date().getFullYear()}`;
    const message = `${emoji} *${title} from Cobb Apparels!* ${emoji}\n\nDear *${customerName || 'Valued Customer'}*,\n\nMay your special day be filled with joy and success! To celebrate with you, enjoy an exclusive *Flat 15% OFF* on your next visit.\n\n🎟️ *VIP Promo Code:* *${code}*\n⏳ _Valid for 7 days in-store._\n\nWe look forward to styling you! 👔✨`;

    try {
        const formatted = String(phone).replace(/[^0-9]/g, '');
        const finalPhone = formatted.length === 10 ? `91${formatted}` : formatted;
        await fetch('http://localhost:3000/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ number: finalPhone, message })
        });
        res.json({ success: true, code });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// --- PILLAR 7: UNIFIED SYSTEM HEALTH WATCHDOG API ---
app.get('/api/system/health', async (req, res) => {
    let dbStatus = 'healthy';
    let dbLatencyMs = 0;
    try {
        const dbStart = Date.now();
        await sql.query('SELECT 1 AS ping');
        dbLatencyMs = Date.now() - dbStart;
    } catch (e) {
        dbStatus = 'degraded';
    }

    let waStatus = 'offline';
    let waDetails = {};
    try {
        const waPing = await fetch('http://localhost:3000/status', { signal: AbortSignal.timeout(2000) });
        if (waPing.ok) {
            waDetails = await waPing.json();
            waStatus = waDetails.isReady ? 'healthy' : (waDetails.qrCodeUrl ? 'awaiting_qr' : 'connecting');
        }
    } catch (e) {
        waStatus = 'offline';
    }

    const listenerStatus = (pythonProcess && pythonProcess.exitCode === null) ? 'healthy' : 'offline';
    const syncStatus = (cloudSyncProcess && !cloudSyncProcess.killed) ? 'healthy' : 'idle';

    const overallHealthy = dbStatus === 'healthy' && waStatus === 'healthy' && listenerStatus === 'healthy';

    res.json({
        overall: overallHealthy ? 'healthy' : (waStatus === 'awaiting_qr' ? 'needs_qr_scan' : 'attention_required'),
        uptimeSeconds: Math.floor(process.uptime()),
        timestamp: new Date().toISOString(),
        services: {
            database: { status: dbStatus, latencyMs: dbLatencyMs, name: 'Microsoft SQL Server' },
            whatsapp: { status: waStatus, isReady: !!waDetails.isReady, qrAvailable: !!waDetails.qrCodeUrl, qrUrl: waDetails.qrCodeUrl, name: 'WhatsApp Gateway' },
            posListener: { status: listenerStatus, name: 'POS Receipt Auto-Listener' },
            cloudSync: { status: syncStatus, name: 'Firebase Cloud Sync' }
        },
        inboundAlertsCount: inboundAlerts.filter(a => a.status === 'unread').length
    });
});

app.post('/api/system/restart-service', async (req, res) => {
    const { service } = req.body || {};
    try {
        if (service === 'whatsapp') {
            if (gatewayProcess) {
                try { spawn('taskkill', ['/PID', gatewayProcess.pid.toString(), '/F', '/T'], { windowsHide: true }); } catch (e) {}
                gatewayProcess = null;
            }
            await startGatewayHelper(true);
            return res.json({ success: true, message: 'WhatsApp Gateway restarted.' });
        }
        if (service === 'posListener') {
            if (pythonProcess) {
                try { spawn('taskkill', ['/PID', pythonProcess.pid.toString(), '/F', '/T'], { windowsHide: true }); } catch (e) {}
                pythonProcess = null;
            }
            startAutomationHelper();
            return res.json({ success: true, message: 'POS Listener restarted.' });
        }
        if (service === 'cloudSync') {
            if (cloudSyncProcess) {
                try { cloudSyncProcess.kill(); } catch (e) {}
                cloudSyncProcess = null;
            }
            startCloudSyncHelper();
            return res.json({ success: true, message: 'Cloud Sync restarted.' });
        }
        res.status(400).json({ error: 'Unknown service: ' + service });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- PILLAR 7: DATABASE BACKUP API ---
app.post('/api/system/backup-now', async (req, res) => {
    try {
        const backupScript = path.join(__dirname, 'scripts', 'backup_db.js');
        if (!fs.existsSync(backupScript)) {
            return res.status(404).json({ error: 'Backup script not found' });
        }
        const child = spawn('node', [backupScript], { cwd: __dirname, shell: false, windowsHide: true });
        let output = '';
        child.stdout.on('data', d => { output += d.toString(); });
        child.stderr.on('data', d => { output += d.toString(); });
        child.on('close', code => {
            if (code === 0) {
                res.json({ success: true, message: 'Database backup generated successfully', output });
            } else {
                res.status(500).json({ error: 'Backup script failed with code ' + code, output });
            }
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log(`CRM Backend running on http://localhost:${PORT}`);
    console.log("Auto-starting Automation Engine, WhatsApp Gateway, and Cloud Sync...");
    startAutomationHelper();
    startGatewayHelper();
    startCloudSyncHelper();

    // Inject WhatsApp sender into Hold Desk router for courtesy pings
    holdsRouter.setSendWhatsApp(async (phone, message) => {
        try {
            const formatted = String(phone).replace(/[^0-9]/g, '');
            const finalPhone = formatted.length === 10 ? `91${formatted}` : formatted;
            await fetch('http://localhost:3000/send', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ number: finalPhone, message })
            });
        } catch (e) {
            console.error('[HoldDesk] WA ping failed:', e.message);
        }
    });

    // --- HIGH-AVAILABILITY SUPERVISOR (Runs every 10 seconds) ---
    // Continuously monitors and auto-heals WhatsApp Gateway, POS Listener, and Cloud Sync
    let consecutiveGatewayFailures = 0;
    setInterval(async () => {
        // 1. WhatsApp Gateway Supervisor (ensures process & port 3000 are alive)
        try {
            const ping = await fetch('http://localhost:3000/status', { signal: AbortSignal.timeout(3000) });
            if (ping.ok) {
                const data = await ping.json().catch(() => ({}));
                if (data.isReady || data.qrCodeUrl) {
                    consecutiveGatewayFailures = 0;
                } else {
                    consecutiveGatewayFailures++;
                    if (consecutiveGatewayFailures >= 6) { // 60 seconds stuck unready without QR code
                        console.log('[SUPERVISOR] WhatsApp Client unready for >60s. Auto-restarting gateway process...');
                        gatewayLogs.push(`[${new Date().toLocaleTimeString()}] [SUPERVISOR] Gateway stuck — auto-restarting cleanly...`);
                        consecutiveGatewayFailures = 0;
                        if (gatewayProcess) {
                            try { spawn('taskkill', ['/PID', gatewayProcess.pid.toString(), '/F', '/T'], { windowsHide: true }); } catch (err) {}
                            gatewayProcess = null;
                        }
                        await startGatewayHelper(true);
                    }
                }
            } else {
                throw new Error('status not ok');
            }
        } catch (e) {
            consecutiveGatewayFailures++;
            // Only trigger recovery if the gateway HTTP server is completely unreachable for 3 consecutive checks (30s)
            if (consecutiveGatewayFailures >= 3) {
                console.log('[SUPERVISOR] WhatsApp Gateway port 3000 is unresponsive (30s). Auto-restarting...');
                gatewayLogs.push(`[${new Date().toLocaleTimeString()}] [SUPERVISOR] Gateway offline — restarting process...`);
                consecutiveGatewayFailures = 0;
                if (gatewayProcess) {
                    try { spawn('taskkill', ['/PID', gatewayProcess.pid.toString(), '/F', '/T'], { windowsHide: true }); } catch (err) {}
                    gatewayProcess = null;
                }
                await startGatewayHelper(true);
            }
        }

        // 2. POS Listener Automation Supervisor
        try {
            if (!pythonProcess || pythonProcess.exitCode !== null) {
                console.log('[SUPERVISOR] cobb_pos_listener is offline. Auto-reviving listener silently...');
                pythonLogs.push(`[${new Date().toLocaleTimeString()}] [SUPERVISOR] Listener down — auto-respawning silently...`);
                pythonProcess = null;
                startAutomationHelper();
            }
        } catch (listenerErr) {
            /* ignore */
        }

        // 3. Cloud Sync Agent Supervisor
        try {
            if (!cloudSyncProcess || cloudSyncProcess.killed) {
                cloudSyncProcess = null;
                startCloudSyncHelper();
            }
        } catch (syncErr) {
            /* ignore */
        }

        // 4. EOD Auto-Dispatch Supervisor & Recovery
        try {
            await checkAndAutoDispatchEod();
        } catch (eodErr) {
            /* ignore */
        }

        // 5. Automated Daily Nightly Database Backup (Runs once after 23:00)
        try {
            await checkAndAutoNightlyBackup();
        } catch (backupErr) {
            /* ignore */
        }
    }, 10000);

    // --- AUTOMATIC EOD CLOSING DISPATCH & RECOVERY ENGINE ---
    let lastEodCheckTimestamp = 0;
    async function checkAndAutoDispatchEod() {
        const nowMs = Date.now();
        if (nowMs - lastEodCheckTimestamp < 30000) return; // Run check every 30s
        lastEodCheckTimestamp = nowMs;

        try {
            const now = new Date();
            const year = now.getFullYear();
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const day = String(now.getDate()).padStart(2, '0');
            const todayStr = `${year}-${month}-${day}`;
            const hour = now.getHours();
            const minute = now.getMinutes();

            const sentFilePath = path.join(__dirname, 'sent_eod_date.txt');
            let lastSentDate = '';
            if (fs.existsSync(sentFilePath)) {
                try {
                    lastSentDate = fs.readFileSync(sentFilePath, 'utf8').trim();
                } catch (e) {}
            }

            // 1. Evening Closing Trigger:
            // Scheduled Closing: 8:30 PM onwards (if PC is still running)
            const isEveningSchedule = (hour > 20 || (hour === 20 && minute >= 30));

            if (lastSentDate !== todayStr && isEveningSchedule) {
                await connectDB();
                const activityQuery = await sql.query(`
                    SELECT COUNT(CM_ID) as billCount
                    FROM CMM01106 WITH (NOLOCK) 
                    WHERE CM_TIME >= CAST(GETDATE() AS DATE) AND CANCELLED = 0
                `);
                const { billCount } = activityQuery.recordset[0] || { billCount: 0 };

                if (billCount > 0) {
                    console.log(`[AUTO EOD] 8:30 PM scheduled closing trigger (${hour}:${String(minute).padStart(2, '0')}) active for ${todayStr} (${billCount} bills). Auto-dispatching EOD digest to owners...`);
                    await dispatchEodReport(todayStr, ' (Store Closing Digest)');
                }
            }

            // 2. Morning / Power-On Recovery: Between 9:00 AM and 1:00 PM
            // If yesterday's digest was never delivered, recover it!
            const isMorningRecovery = (hour >= 9 && hour <= 13);
            const yesterday = new Date(now);
            yesterday.setDate(yesterday.getDate() - 1);
            const yesterdayStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;

            if (isMorningRecovery && lastSentDate !== yesterdayStr && lastSentDate !== todayStr) {
                console.log(`[AUTO EOD RECOVERY] Yesterday's (${yesterdayStr}) digest was not recorded as sent. Checking if bills exist...`);
                await connectDB();
                const checkQuery = await sql.query(`
                    SELECT COUNT(CM_ID) as billCount 
                    FROM CMM01106 WITH (NOLOCK) 
                    WHERE CM_TIME >= '${yesterdayStr}' AND CM_TIME < CAST(GETDATE() AS DATE) AND CANCELLED = 0
                `);
                const billCount = checkQuery.recordset[0]?.billCount || 0;
                if (billCount > 0) {
                    console.log(`[AUTO EOD RECOVERY] Found ${billCount} bills from yesterday. Sending recovered night closing digest...`);
                    await dispatchEodReport(yesterdayStr, ' (Recovered Night Closing)');
                } else {
                    try {
                        fs.writeFileSync(sentFilePath, yesterdayStr, 'utf8');
                    } catch (e) {}
                }
            }
        } catch (err) {
            console.error('[AUTO EOD CHECK ERROR]:', err.message);
        }
    }

    let lastBackupDate = '';
    async function checkAndAutoNightlyBackup() {
        const now = new Date();
        const todayStr = now.toISOString().split('T')[0];
        if (now.getHours() >= 23 && lastBackupDate !== todayStr) {
            lastBackupDate = todayStr;
            const backupScript = path.join(__dirname, 'scripts', 'backup_db.js');
            if (fs.existsSync(backupScript)) {
                console.log(`[SUPERVISOR] Executing scheduled nightly database backup for ${todayStr}...`);
                spawn('node', [backupScript], { cwd: __dirname, shell: false, windowsHide: true, stdio: 'ignore' });
            }
        }
    }
});

// --- GRACEFUL PROCESS TERMINATION / WINDOWS SHUTDOWN HOOK ---
async function handleProcessTermination(signal) {
    console.log(`[PROCESS TERMINATION] Received ${signal}. Checking for unsent evening EOD digest...`);
    try {
        const now = new Date();
        const hour = now.getHours();
        const minute = now.getMinutes();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const todayStr = `${year}-${month}-${day}`;

        // Evening closing window: 6:00 PM (18:00) onwards
        if (hour >= 18) {
            const sentFilePath = path.join(__dirname, 'sent_eod_date.txt');
            let lastSentDate = '';
            if (fs.existsSync(sentFilePath)) {
                try { lastSentDate = fs.readFileSync(sentFilePath, 'utf8').trim(); } catch (e) {}
            }
            if (lastSentDate !== todayStr) {
                console.log(`[PROCESS TERMINATION] Evening shutdown at ${hour}:${String(minute).padStart(2, '0')}. Dispatching EOD digest for ${todayStr}...`);
                await dispatchEodReport(todayStr, ' (Store Closing Digest)');
            }
        }
    } catch (e) {
        console.error('[PROCESS TERMINATION EOD ERROR]:', e.message);
    }
}

process.on('SIGTERM', async () => {
    await handleProcessTermination('SIGTERM');
    process.exit(0);
});
process.on('SIGINT', async () => {
    await handleProcessTermination('SIGINT');
    process.exit(0);
});
process.on('SIGBREAK', async () => {
    await handleProcessTermination('SIGBREAK');
    process.exit(0);
});
process.on('message', async (msg) => {
    if (msg === 'shutdown') {
        await handleProcessTermination('pm2:shutdown');
        process.exit(0);
    }
});

