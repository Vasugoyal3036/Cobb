@echo off
title Cobb Retail CRM - First Time Setup
echo ============================================================
echo   Cobb Retail CRM - First Time Setup
echo ============================================================
echo.
echo Step 1: Installing Backend dependencies...
cd CobbDashboard
call npm install
echo.
echo Step 2: Installing Frontend dependencies...
cd ..\cobb-ui
call npm install
echo.
echo ============================================================
echo   Setup Complete!
echo.
echo   NEXT STEPS:
echo   1. Open CobbDashboard\.env.example, save it as .env
echo      and fill in your SQL Server database details.
echo.
echo   2. Open cobb-ui\.env.example, save it as .env
echo      (Firebase fields are optional).
echo.
echo   3. Double-click start_local.bat to launch the CRM!
echo ============================================================
pause
